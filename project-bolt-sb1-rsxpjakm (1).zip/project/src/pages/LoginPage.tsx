import React, { useState, useEffect } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { User, Building, Eye, EyeOff, Mail, AlertCircle, CheckCircle } from 'lucide-react';

const LoginPage = () => {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const [userType, setUserType] = useState<'brand' | 'influencer'>('brand');
  const [showPassword, setShowPassword] = useState(false);
  const [showForgotPassword, setShowForgotPassword] = useState(false);
  const [isLogin, setIsLogin] = useState(true);
  const [isLoading, setIsLoading] = useState(false);
  const [notification, setNotification] = useState<{type: 'success' | 'error', message: string} | null>(null);
  
  const [formData, setFormData] = useState({
    email: '',
    password: '',
    confirmPassword: '',
    companyName: '',
    fullName: ''
  });
  const [forgotEmail, setForgotEmail] = useState('');

  useEffect(() => {
    const role = searchParams.get('role');
    if (role === 'influencer') {
      setUserType('influencer');
    }
  }, [searchParams]);

  const showNotification = (type: 'success' | 'error', message: string) => {
    setNotification({ type, message });
    setTimeout(() => setNotification(null), 5000);
  };

  const validateForm = () => {
    if (!formData.email || !formData.password) {
      showNotification('error', 'E-posta ve şifre alanları zorunludur.');
      return false;
    }

    if (!isLogin) {
      if (formData.password !== formData.confirmPassword) {
        showNotification('error', 'Şifreler eşleşmiyor.');
        return false;
      }
      if (formData.password.length < 6) {
        showNotification('error', 'Şifre en az 6 karakter olmalıdır.');
        return false;
      }
      if (userType === 'brand' && !formData.companyName) {
        showNotification('error', 'Şirket adı zorunludur.');
        return false;
      }
      if (userType === 'influencer' && !formData.fullName) {
        showNotification('error', 'Ad soyad zorunludur.');
        return false;
      }
    }

    return true;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateForm()) return;

    setIsLoading(true);

    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1500));

      if (isLogin) {
        // Demo login logic
        const demoCredentials = {
          brand: { email: 'demo@marka.com', password: '123456' },
          influencer: { email: 'demo@etkileyici.com', password: '123456' }
        };

        const demo = demoCredentials[userType];
        if (formData.email === demo.email && formData.password === demo.password) {
          // Store login state
          localStorage.setItem('userType', userType);
          localStorage.setItem('isLoggedIn', 'true');
          localStorage.setItem('userEmail', formData.email);
          
          showNotification('success', 'Giriş başarılı! Yönlendiriliyorsunuz...');
          
          setTimeout(() => {
            if (userType === 'brand') {
              navigate('/brand-dashboard');
            } else {
              navigate('/influencer-dashboard');
            }
          }, 1000);
        } else {
          showNotification('error', 'E-posta veya şifre hatalı. Demo hesapları deneyin.');
        }
      } else {
        // Registration logic
        // In a real app, this would create a new user account
        localStorage.setItem('userType', userType);
        localStorage.setItem('isLoggedIn', 'true');
        localStorage.setItem('userEmail', formData.email);
        
        showNotification('success', 'Hesabınız başarıyla oluşturuldu! Yönlendiriliyorsunuz...');
        
        setTimeout(() => {
          if (userType === 'brand') {
            navigate('/brand-dashboard');
          } else {
            navigate('/influencer-dashboard');
          }
        }, 1000);
      }
    } catch (error) {
      showNotification('error', 'Bir hata oluştu. Lütfen tekrar deneyin.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleForgotPassword = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!forgotEmail) {
      showNotification('error', 'E-posta adresi gereklidir.');
      return;
    }

    setIsLoading(true);
    
    try {
      // Simulate password reset email
      await new Promise(resolve => setTimeout(resolve, 1000));
      showNotification('success', `Şifre sıfırlama linki ${forgotEmail} adresine gönderildi!`);
      setShowForgotPassword(false);
      setForgotEmail('');
    } catch (error) {
      showNotification('error', 'E-posta gönderilirken bir hata oluştu.');
    } finally {
      setIsLoading(false);
    }
  };

  console.log('✅ [LoginPage with Full Authentication] tamamlandı');

  if (showForgotPassword) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-900 via-blue-800 to-orange-600 flex items-center justify-center p-4">
        <div className="bg-white rounded-2xl max-w-md w-full p-8 shadow-xl">
          <div className="text-center mb-8">
            <div className="w-16 h-16 bg-gradient-to-br from-blue-800 to-orange-600 rounded-2xl flex items-center justify-center mx-auto mb-4">
              <Mail className="w-8 h-8 text-white" />
            </div>
            <h1 className="text-2xl font-bold text-gray-900 mb-2">Şifremi Unuttum</h1>
            <p className="text-gray-600">E-posta adresinizi girin, size şifre sıfırlama linki gönderelim</p>
          </div>

          <form onSubmit={handleForgotPassword} className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                E-posta
              </label>
              <input
                type="email"
                value={forgotEmail}
                onChange={(e) => setForgotEmail(e.target.value)}
                className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                placeholder="ornek@email.com"
                required
              />
            </div>
            
            <button 
              type="submit"
              disabled={isLoading}
              className="w-full bg-blue-600 hover:bg-blue-700 text-white py-3 rounded-xl font-semibold transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {isLoading ? 'Gönderiliyor...' : 'Şifre Sıfırlama Linki Gönder'}
            </button>
          </form>

          <div className="text-center mt-6">
            <button 
              onClick={() => setShowForgotPassword(false)}
              className="text-blue-600 hover:text-blue-700 text-sm"
            >
              Giriş sayfasına dön
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-900 via-blue-800 to-orange-600 flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl max-w-md w-full p-8 shadow-xl">
        {/* Notification */}
        {notification && (
          <div className={`mb-6 p-4 rounded-xl flex items-center space-x-2 ${
            notification.type === 'success' 
              ? 'bg-green-50 border border-green-200 text-green-800' 
              : 'bg-red-50 border border-red-200 text-red-800'
          }`}>
            {notification.type === 'success' ? (
              <CheckCircle className="w-5 h-5" />
            ) : (
              <AlertCircle className="w-5 h-5" />
            )}
            <span className="text-sm">{notification.message}</span>
          </div>
        )}

        <div className="text-center mb-8">
          <div className="w-16 h-16 bg-gradient-to-br from-blue-800 to-orange-600 rounded-2xl flex items-center justify-center mx-auto mb-4">
            <span className="text-white font-bold text-xl">Mİ</span>
          </div>
          <h1 className="text-2xl font-bold text-gray-900 mb-2">
            MikroEtki'ye {isLogin ? 'Giriş' : 'Kayıt Ol'}
          </h1>
          <p className="text-gray-600">
            {isLogin ? 'Hesabınıza giriş yapın' : 'Yeni hesap oluşturun'}
          </p>
        </div>

        {/* User Type Selection */}
        <div className="grid grid-cols-2 gap-4 mb-6">
          <button
            onClick={() => setUserType('brand')}
            className={`p-4 rounded-xl border-2 transition-all ${
              userType === 'brand' 
                ? 'border-blue-500 bg-blue-50' 
                : 'border-gray-200 hover:border-gray-300'
            }`}
          >
            <Building className="w-8 h-8 mx-auto mb-2 text-blue-600" />
            <div className="font-semibold">Marka/İşletme</div>
            <div className="text-sm text-gray-600">Etkileyici arıyorum</div>
          </button>
          <button
            onClick={() => setUserType('influencer')}
            className={`p-4 rounded-xl border-2 transition-all ${
              userType === 'influencer' 
                ? 'border-orange-500 bg-orange-50' 
                : 'border-gray-200 hover:border-gray-300'
            }`}
          >
            <User className="w-8 h-8 mx-auto mb-2 text-orange-600" />
            <div className="font-semibold">Etkileyici</div>
            <div className="text-sm text-gray-600">İş fırsatları arıyorum</div>
          </button>
        </div>

        {/* Demo Credentials Info */}
        {isLogin && (
          <div className="bg-yellow-50 border border-yellow-200 rounded-xl p-4 mb-6">
            <h3 className="font-semibold text-yellow-800 mb-2">Demo Giriş Bilgileri:</h3>
            <div className="text-sm text-yellow-700 space-y-1">
              <p><strong>Marka/İşletme:</strong> demo@marka.com / 123456</p>
              <p><strong>Etkileyici:</strong> demo@etkileyici.com / 123456</p>
            </div>
          </div>
        )}

        {/* Form */}
        <form onSubmit={handleSubmit} className="space-y-4">
          {!isLogin && userType === 'brand' && (
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Şirket Adı
              </label>
              <input
                type="text"
                value={formData.companyName}
                onChange={(e) => setFormData({...formData, companyName: e.target.value})}
                className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                placeholder="Şirket adınız"
                required={!isLogin}
              />
            </div>
          )}

          {!isLogin && userType === 'influencer' && (
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Ad Soyad
              </label>
              <input
                type="text"
                value={formData.fullName}
                onChange={(e) => setFormData({...formData, fullName: e.target.value})}
                className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                placeholder="Adınız ve soyadınız"
                required={!isLogin}
              />
            </div>
          )}

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              E-posta
            </label>
            <input
              type="email"
              value={formData.email}
              onChange={(e) => setFormData({...formData, email: e.target.value})}
              className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              placeholder="ornek@email.com"
              required
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Şifre
            </label>
            <div className="relative">
              <input
                type={showPassword ? 'text' : 'password'}
                value={formData.password}
                onChange={(e) => setFormData({...formData, password: e.target.value})}
                className="w-full px-4 py-3 pr-12 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                placeholder="••••••••"
                required
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-gray-600"
              >
                {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
              </button>
            </div>
          </div>

          {!isLogin && (
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Şifre Tekrar
              </label>
              <input
                type="password"
                value={formData.confirmPassword}
                onChange={(e) => setFormData({...formData, confirmPassword: e.target.value})}
                className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                placeholder="••••••••"
                required={!isLogin}
              />
            </div>
          )}
          
          <button 
            type="submit"
            disabled={isLoading}
            className={`w-full py-3 rounded-xl font-semibold transition-colors disabled:opacity-50 disabled:cursor-not-allowed ${
              userType === 'brand'
                ? 'bg-blue-600 hover:bg-blue-700 text-white'
                : 'bg-orange-600 hover:bg-orange-700 text-white'
            }`}
          >
            {isLoading ? 'İşleniyor...' : (isLogin ? 'Giriş Yap' : 'Hesap Oluştur')}
          </button>
        </form>

        {isLogin && (
          <div className="text-center mt-6">
            <button 
              onClick={() => setShowForgotPassword(true)}
              className="text-blue-600 hover:text-blue-700 text-sm"
            >
              Şifremi Unuttum
            </button>
          </div>
        )}

        <div className="text-center mt-4">
          <span className="text-gray-600 text-sm">
            {isLogin ? 'Hesabınız yok mu?' : 'Zaten hesabınız var mı?'} 
          </span>
          <button 
            onClick={() => setIsLogin(!isLogin)}
            className="text-blue-600 hover:text-blue-700 text-sm font-medium ml-1"
          >
            {isLogin ? 'Kayıt Olun' : 'Giriş Yapın'}
          </button>
        </div>
      </div>
    </div>
  );
};

export default LoginPage;