import React from 'react';
import { useParams } from 'react-router-dom';
import DetailedProfile from '../components/InfluencerProfile/DetailedProfile';

const InfluencerDetail = () => {
  const { id } = useParams();
  const influencerId = parseInt(id || '1');

  console.log('✅ [InfluencerDetail Page] tamamlandı');

  return <DetailedProfile influencerId={influencerId} />;
};

export default InfluencerDetail;