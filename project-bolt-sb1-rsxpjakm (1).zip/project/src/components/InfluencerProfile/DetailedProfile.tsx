import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  MapPin, Users, TrendingUp, Heart, MessageCircle, Share, Star, 
  Instagram, Youtube, Play, Calendar, Award, Shield, Eye,
  BarChart3, PieChart, Activity, Globe, Camera, Video, ArrowLeft
} from 'lucide-react';
import ContactModal from '../ContactModal';

interface InfluencerProfileProps {
  influencerId: number;
}

const DetailedProfile: React.FC<InfluencerProfileProps> = ({ influencerId }) => {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState('overview');
  const [showContactModal, setShowContactModal] = useState(false);

  // Mock detailed data based on influencer ID
  const getInfluencerData = (id: number) => {
    const baseData = {
      1: {
        name: 'Ayşe Demir',
        username: 'aysedemir_style',
        category: 'Moda & Güzellik',
        bio: 'Moda ve güzellik tutkunu. Sürdürülebilir yaşam savunucusu. İstanbul\'dan sevgilerle ✨ #SustainableFashion #BeautyTips',
        priceRange: '₺2,500 - ₺4,000'
      },
      2: {
        name: 'Mehmet Özkan',
        username: 'mehmet_foodie',
        category: 'Yemek & Mutfak',
        bio: 'Lezzetli yemekler ve mutfak hikayeleri. İstanbul\'un en iyi restoranlarını keşfediyorum 🍽️',
        priceRange: '₺1,800 - ₺3,200'
      },
      3: {
        name: 'Zeynep Yılmaz',
        username: 'zeynep_travels',
        category: 'Seyahat',
        bio: 'Dünyayı keşfetmeyi seven bir gezgin. Her yolculukta yeni hikayeler 🌍 ✈️',
        priceRange: '₺3,500 - ₺5,500'
      }
    };

    return baseData[id as keyof typeof baseData] || baseData[1];
  };

  const influencerData = getInfluencerData(influencerId);

  const influencer = {
    id: influencerId,
    ...influencerData,
    avatar: `https://images.pexels.com/photos/1036623/pexels-photo-1036623.jpeg?auto=compress&cs=tinysrgb&w=400`,
    coverImage: 'https://images.pexels.com/photos/1040880/pexels-photo-1040880.jpeg?auto=compress&cs=tinysrgb&w=1200',
    location: 'İstanbul, Türkiye',
    followers: 15400,
    engagement: 8.2,
    avgLikes: 1250,
    avgComments: 89,
    rating: 4.8,
    recentCampaigns: 12,
    verified: true,
    trustScore: 92,
    responseTime: '2 saat',
    languages: ['Türkçe', 'İngilizce'],
    collaborationTypes: ['Sponsored Posts', 'Product Reviews', 'Brand Ambassadorship'],
    
    // Detailed analytics
    demographics: {
      age: {
        '18-24': 35,
        '25-34': 42,
        '35-44': 18,
        '45+': 5
      },
      gender: {
        female: 68,
        male: 32
      },
      location: {
        'İstanbul': 45,
        'Ankara': 15,
        'İzmir': 12,
        'Bursa': 8,
        'Diğer': 20
      }
    },
    
    // Performance data
    performance: {
      engagementTrend: [6.5, 7.2, 8.1, 7.8, 8.2, 8.5, 8.2],
      followerGrowth: [14200, 14500, 14800, 15100, 15200, 15300, 15400],
      bestPostingTimes: ['19:00-21:00', '12:00-14:00', '09:00-11:00'],
      topHashtags: ['#moda', '#güzellik', '#istanbul', '#style', '#fashion']
    },
    
    // Recent posts
    recentPosts: [
      {
        id: 1,
        image: 'https://images.pexels.com/photos/1040880/pexels-photo-1040880.jpeg?auto=compress&cs=tinysrgb&w=400',
        likes: 1450,
        comments: 89,
        date: '2024-01-15',
        type: 'image'
      },
      {
        id: 2,
        image: 'https://images.pexels.com/photos/1036623/pexels-photo-1036623.jpeg?auto=compress&cs=tinysrgb&w=400',
        likes: 1320,
        comments: 76,
        date: '2024-01-12',
        type: 'carousel'
      },
      {
        id: 3,
        image: 'https://images.pexels.com/photos/1130626/pexels-photo-1130626.jpeg?auto=compress&cs=tinysrgb&w=400',
        likes: 1680,
        comments: 102,
        date: '2024-01-10',
        type: 'video'
      }
    ],
    
    // Social media accounts
    socialAccounts: {
      instagram: {
        handle: influencerData.username,
        followers: 15400,
        engagement: 8.2,
        avgLikes: 1250,
        avgComments: 89,
        verified: true,
        posts: 342
      },
      tiktok: {
        handle: influencerData.username,
        followers: 8900,
        engagement: 12.5,
        avgViews: 2500,
        verified: false,
        videos: 156
      },
      youtube: {
        handle: influencerData.name.replace(' ', ''),
        subscribers: 5200,
        avgViews: 1800,
        totalVideos: 45,
        verified: false
      }
    }
  };

  const formatNumber = (num: number) => {
    if (num >= 1000000) return `${(num / 1000000).toFixed(1)}M`;
    if (num >= 1000) return `${(num / 1000).toFixed(1)}K`;
    return num.toString();
  };

  const handleContact = () => {
    const isLoggedIn = localStorage.getItem('isLoggedIn') === 'true';
    const userType = localStorage.getItem('userType');
    
    if (!isLoggedIn) {
      navigate('/login?role=brand');
      return;
    }
    
    if (userType !== 'brand') {
      alert('Sadece marka hesapları etkileyicilerle iletişime geçebilir.');
      return;
    }
    
    setShowContactModal(true);
  };

  const handleSaveToFavorites = () => {
    const isLoggedIn = localStorage.getItem('isLoggedIn') === 'true';
    if (!isLoggedIn) {
      navigate('/login?role=brand');
      return;
    }
    
    alert(`${influencer.name} favorilere eklendi!`);
  };

  const handleShare = () => {
    const url = `${window.location.origin}/influencer/${influencer.id}`;
    if (navigator.share) {
      navigator.share({
        title: `${influencer.name} - MikroEtki`,
        text: `${influencer.name} profilini inceleyin`,
        url: url
      });
    } else {
      navigator.clipboard.writeText(url);
      alert('Profil linki kopyalandı!');
    }
  };

  console.log('✅ [DetailedProfile with Contact Integration] tamamlandı');

  return (
    <>
      <div className="min-h-screen bg-gray-50">
        {/* Header */}
        <div className="bg-white shadow-sm border-b border-gray-200">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex items-center h-16">
              <button 
                onClick={() => navigate(-1)}
                className="flex items-center space-x-2 text-gray-600 hover:text-gray-900 transition-colors mr-6"
              >
                <ArrowLeft className="w-5 h-5" />
                <span>Geri</span>
              </button>
              <div className="w-8 h-8 bg-gradient-to-br from-blue-800 to-orange-600 rounded-lg flex items-center justify-center">
                <span className="text-white font-bold text-sm">Mİ</span>
              </div>
              <span className="ml-2 text-xl font-bold text-gray-900">MikroEtki</span>
            </div>
          </div>
        </div>

        {/* Cover & Profile Header */}
        <div className="relative">
          <div 
            className="h-64 bg-cover bg-center"
            style={{ backgroundImage: `url(${influencer.coverImage})` }}
          >
            <div className="absolute inset-0 bg-black bg-opacity-40"></div>
          </div>
          
          <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex flex-col md:flex-row items-start md:items-end space-y-4 md:space-y-0 md:space-x-6 -mt-16">
              <div className="relative">
                <img
                  src={influencer.avatar}
                  alt={influencer.name}
                  className="w-32 h-32 rounded-full border-4 border-white shadow-lg object-cover"
                />
                {influencer.verified && (
                  <div className="absolute bottom-2 right-2 w-8 h-8 bg-blue-500 rounded-full flex items-center justify-center border-2 border-white">
                    <div className="w-3 h-3 bg-white rounded-full"></div>
                  </div>
                )}
              </div>
              
              <div className="flex-1 bg-white rounded-2xl p-6 shadow-lg">
                <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between">
                  <div className="mb-4 lg:mb-0">
                    <h1 className="text-3xl font-bold text-gray-900 mb-2">{influencer.name}</h1>
                    <p className="text-lg text-gray-600 mb-2">@{influencer.username}</p>
                    <div className="flex items-center space-x-4 text-sm text-gray-600">
                      <div className="flex items-center space-x-1">
                        <MapPin className="w-4 h-4" />
                        <span>{influencer.location}</span>
                      </div>
                      <div className="flex items-center space-x-1">
                        <Star className="w-4 h-4 text-yellow-400 fill-current" />
                        <span>{influencer.rating} puan</span>
                      </div>
                      <div className="flex items-center space-x-1">
                        <Shield className="w-4 h-4 text-green-500" />
                        <span>%{influencer.trustScore} güven skoru</span>
                      </div>
                    </div>
                  </div>
                  
                  <div className="flex space-x-3">
                    <button 
                      onClick={handleSaveToFavorites}
                      className="px-4 py-2 border border-gray-300 rounded-xl hover:bg-gray-50 transition-colors flex items-center space-x-2"
                    >
                      <Heart className="w-4 h-4" />
                      <span>Favorile</span>
                    </button>
                    <button 
                      onClick={handleShare}
                      className="px-4 py-2 border border-gray-300 rounded-xl hover:bg-gray-50 transition-colors"
                    >
                      <Share className="w-4 h-4" />
                    </button>
                    <button 
                      onClick={handleContact}
                      className="px-6 py-2 bg-blue-600 text-white rounded-xl hover:bg-blue-700 transition-colors font-medium"
                    >
                      İletişime Geç
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Navigation Tabs */}
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-8">
          <div className="bg-white rounded-2xl shadow-sm border border-gray-200 p-2">
            <nav className="flex space-x-2 overflow-x-auto">
              {[
                { id: 'overview', label: 'Genel Bakış', icon: Eye },
                { id: 'analytics', label: 'Analitik', icon: BarChart3 },
                { id: 'demographics', label: 'Demografi', icon: PieChart },
                { id: 'content', label: 'İçerikler', icon: Camera },
                { id: 'performance', label: 'Performans', icon: TrendingUp }
              ].map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`flex items-center space-x-2 px-4 py-3 rounded-xl transition-colors whitespace-nowrap ${
                    activeTab === tab.id
                      ? 'bg-blue-50 text-blue-700 border border-blue-200'
                      : 'text-gray-600 hover:text-gray-900 hover:bg-gray-50'
                  }`}
                >
                  <tab.icon className="w-4 h-4" />
                  <span>{tab.label}</span>
                </button>
              ))}
            </nav>
          </div>
        </div>

        {/* Tab Content */}
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          {activeTab === 'overview' && (
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              {/* Left Column */}
              <div className="lg:col-span-2 space-y-8">
                {/* Bio */}
                <div className="bg-white rounded-2xl shadow-sm border border-gray-200 p-6">
                  <h2 className="text-xl font-semibold text-gray-900 mb-4">Hakkında</h2>
                  <p className="text-gray-700 leading-relaxed mb-4">{influencer.bio}</p>
                  <div className="flex flex-wrap gap-2">
                    {influencer.collaborationTypes.map((type, index) => (
                      <span key={index} className="px-3 py-1 bg-blue-100 text-blue-800 rounded-full text-sm">
                        {type}
                      </span>
                    ))}
                  </div>
                </div>

                {/* Key Metrics */}
                <div className="bg-white rounded-2xl shadow-sm border border-gray-200 p-6">
                  <h2 className="text-xl font-semibold text-gray-900 mb-6">Temel Metrikler</h2>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
                    <div className="text-center">
                      <div className="w-12 h-12 bg-blue-100 rounded-xl flex items-center justify-center mx-auto mb-3">
                        <Users className="w-6 h-6 text-blue-600" />
                      </div>
                      <p className="text-2xl font-bold text-gray-900">{formatNumber(influencer.followers)}</p>
                      <p className="text-sm text-gray-600">Toplam Takipçi</p>
                    </div>
                    <div className="text-center">
                      <div className="w-12 h-12 bg-green-100 rounded-xl flex items-center justify-center mx-auto mb-3">
                        <TrendingUp className="w-6 h-6 text-green-600" />
                      </div>
                      <p className="text-2xl font-bold text-gray-900">{influencer.engagement}%</p>
                      <p className="text-sm text-gray-600">Etkileşim Oranı</p>
                    </div>
                    <div className="text-center">
                      <div className="w-12 h-12 bg-orange-100 rounded-xl flex items-center justify-center mx-auto mb-3">
                        <Heart className="w-6 h-6 text-orange-600" />
                      </div>
                      <p className="text-2xl font-bold text-gray-900">{formatNumber(influencer.avgLikes)}</p>
                      <p className="text-sm text-gray-600">Ortalama Beğeni</p>
                    </div>
                    <div className="text-center">
                      <div className="w-12 h-12 bg-purple-100 rounded-xl flex items-center justify-center mx-auto mb-3">
                        <MessageCircle className="w-6 h-6 text-purple-600" />
                      </div>
                      <p className="text-2xl font-bold text-gray-900">{influencer.avgComments}</p>
                      <p className="text-sm text-gray-600">Ortalama Yorum</p>
                    </div>
                  </div>
                </div>

                {/* Social Media Accounts */}
                <div className="bg-white rounded-2xl shadow-sm border border-gray-200 p-6">
                  <h2 className="text-xl font-semibold text-gray-900 mb-6">Sosyal Medya Hesapları</h2>
                  <div className="space-y-4">
                    {/* Instagram */}
                    <div className="flex items-center justify-between p-4 border border-gray-200 rounded-xl">
                      <div className="flex items-center space-x-4">
                        <Instagram className="w-8 h-8 text-pink-600" />
                        <div>
                          <h3 className="font-semibold text-gray-900">Instagram</h3>
                          <p className="text-sm text-gray-600">@{influencer.socialAccounts.instagram.handle}</p>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="font-semibold text-gray-900">{formatNumber(influencer.socialAccounts.instagram.followers)}</p>
                        <p className="text-sm text-gray-600">{influencer.socialAccounts.instagram.engagement}% etkileşim</p>
                      </div>
                    </div>

                    {/* TikTok */}
                    <div className="flex items-center justify-between p-4 border border-gray-200 rounded-xl">
                      <div className="flex items-center space-x-4">
                        <Play className="w-8 h-8 text-black" />
                        <div>
                          <h3 className="font-semibold text-gray-900">TikTok</h3>
                          <p className="text-sm text-gray-600">@{influencer.socialAccounts.tiktok.handle}</p>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="font-semibold text-gray-900">{formatNumber(influencer.socialAccounts.tiktok.followers)}</p>
                        <p className="text-sm text-gray-600">{influencer.socialAccounts.tiktok.engagement}% etkileşim</p>
                      </div>
                    </div>

                    {/* YouTube */}
                    <div className="flex items-center justify-between p-4 border border-gray-200 rounded-xl">
                      <div className="flex items-center space-x-4">
                        <Youtube className="w-8 h-8 text-red-600" />
                        <div>
                          <h3 className="font-semibold text-gray-900">YouTube</h3>
                          <p className="text-sm text-gray-600">{influencer.socialAccounts.youtube.handle}</p>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="font-semibold text-gray-900">{formatNumber(influencer.socialAccounts.youtube.subscribers)}</p>
                        <p className="text-sm text-gray-600">{influencer.socialAccounts.youtube.totalVideos} video</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Right Column */}
              <div className="space-y-8">
                {/* Contact Info */}
                <div className="bg-white rounded-2xl shadow-sm border border-gray-200 p-6">
                  <h2 className="text-xl font-semibold text-gray-900 mb-6">İletişim Bilgileri</h2>
                  <div className="space-y-4">
                    <div>
                      <p className="text-sm text-gray-600">Fiyat Aralığı</p>
                      <p className="font-semibold text-gray-900">{influencer.priceRange}</p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-600">Yanıt Süresi</p>
                      <p className="font-semibold text-gray-900">{influencer.responseTime}</p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-600">Diller</p>
                      <div className="flex flex-wrap gap-2 mt-1">
                        {influencer.languages.map((lang, index) => (
                          <span key={index} className="px-2 py-1 bg-gray-100 text-gray-700 rounded-full text-sm">
                            {lang}
                          </span>
                        ))}
                      </div>
                    </div>
                    <div>
                      <p className="text-sm text-gray-600">Son Kampanyalar</p>
                      <p className="font-semibold text-gray-900">{influencer.recentCampaigns} kampanya (3 ay)</p>
                    </div>
                  </div>
                  
                  <button 
                    onClick={handleContact}
                    className="w-full mt-6 bg-blue-600 text-white py-3 rounded-xl hover:bg-blue-700 transition-colors font-medium"
                  >
                    Teklif Gönder
                  </button>
                </div>

                {/* Trust Score */}
                <div className="bg-white rounded-2xl shadow-sm border border-gray-200 p-6">
                  <h2 className="text-xl font-semibold text-gray-900 mb-6">Güven Endeksi</h2>
                  <div className="text-center">
                    <div className="relative w-24 h-24 mx-auto mb-4">
                      <div className="w-24 h-24 rounded-full border-8 border-gray-200"></div>
                      <div 
                        className="absolute top-0 left-0 w-24 h-24 rounded-full border-8 border-green-500"
                        style={{ 
                          clipPath: `polygon(50% 50%, 50% 0%, ${50 + (influencer.trustScore / 100) * 50}% 0%, 100% 100%, 0% 100%)` 
                        }}
                      ></div>
                      <div className="absolute inset-0 flex items-center justify-center">
                        <span className="text-xl font-bold text-gray-900">{influencer.trustScore}</span>
                      </div>
                    </div>
                    <p className="text-sm text-gray-600">Güvenilirlik Skoru</p>
                    <p className="text-xs text-gray-500 mt-2">
                      Etkileşim kalitesi, sahte takipçi analizi ve geçmiş performansa dayalı
                    </p>
                  </div>
                </div>

                {/* Recent Activity */}
                <div className="bg-white rounded-2xl shadow-sm border border-gray-200 p-6">
                  <h2 className="text-xl font-semibold text-gray-900 mb-6">Son Aktivite</h2>
                  <div className="space-y-3">
                    <div className="flex items-center space-x-3 text-sm">
                      <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                      <span className="text-gray-600">2 saat önce aktifti</span>
                    </div>
                    <div className="flex items-center space-x-3 text-sm">
                      <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                      <span className="text-gray-600">Yeni post paylaştı</span>
                    </div>
                    <div className="flex items-center space-x-3 text-sm">
                      <div className="w-2 h-2 bg-orange-500 rounded-full"></div>
                      <span className="text-gray-600">Story güncelledi</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Other tab contents would go here */}
          {activeTab !== 'overview' && (
            <div className="bg-white rounded-2xl shadow-sm border border-gray-200 p-8 text-center">
              <h2 className="text-2xl font-bold text-gray-900 mb-4">
                {activeTab === 'analytics' && 'Analitik Verileri'}
                {activeTab === 'demographics' && 'Demografik Bilgiler'}
                {activeTab === 'content' && 'İçerik Galerisi'}
                {activeTab === 'performance' && 'Performans Metrikleri'}
              </h2>
              <p className="text-gray-600">Bu bölüm yakında aktif olacak.</p>
            </div>
          )}
        </div>
      </div>

      {/* Contact Modal */}
      <ContactModal
        isOpen={showContactModal}
        onClose={() => setShowContactModal(false)}
        influencer={{
          id: influencer.id,
          name: influencer.name,
          username: influencer.username,
          avatar: influencer.avatar,
          category: influencer.category,
          priceRange: influencer.priceRange
        }}
      />
    </>
  );
};

export default DetailedProfile;