import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import InfluencerCard from './InfluencerCard';

interface FilterState {
  searchTerm: string;
  category: string;
  location: string;
  followersRange: string;
  engagementRange: string;
  isActive: boolean;
  isBudgetFriendly: boolean;
}

interface InfluencerGridProps {
  onViewProfile?: (id: number) => void;
  filters?: FilterState;
}

const InfluencerGrid: React.FC<InfluencerGridProps> = ({ onViewProfile, filters }) => {
  const navigate = useNavigate();
  const [sortBy, setSortBy] = useState('recommended');
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [filteredInfluencers, setFilteredInfluencers] = useState<any[]>([]);
  
  // Mock data for demonstration
  const allInfluencers = [
    {
      id: 1,
      name: 'Ayşe Demir',
      username: 'aysedemir_style',
      avatar: 'https://images.pexels.com/photos/1036623/pexels-photo-1036623.jpeg?auto=compress&cs=tinysrgb&w=400',
      location: 'İstanbul',
      category: 'Moda & Güzellik',
      followers: 15400,
      engagement: 8.2,
      avgLikes: 1250,
      avgComments: 89,
      rating: 4.8,
      priceRange: '₺2,500 - ₺4,000',
      recentCampaigns: 12,
      verified: true,
      isActive: true,
      isBudgetFriendly: false
    },
    {
      id: 2,
      name: 'Mehmet Özkan',
      username: 'mehmet_foodie',
      avatar: 'https://images.pexels.com/photos/1043471/pexels-photo-1043471.jpeg?auto=compress&cs=tinysrgb&w=400',
      location: 'Ankara',
      category: 'Yemek & Mutfak',
      followers: 8900,
      engagement: 12.5,
      avgLikes: 980,
      avgComments: 145,
      rating: 4.9,
      priceRange: '₺1,800 - ₺3,200',
      recentCampaigns: 8,
      verified: false,
      isActive: true,
      isBudgetFriendly: true
    },
    {
      id: 3,
      name: 'Zeynep Yılmaz',
      username: 'zeynep_travels',
      avatar: 'https://images.pexels.com/photos/1130626/pexels-photo-1130626.jpeg?auto=compress&cs=tinysrgb&w=400',
      location: 'İzmir',
      category: 'Seyahat',
      followers: 22100,
      engagement: 6.8,
      avgLikes: 1450,
      avgComments: 67,
      rating: 4.7,
      priceRange: '₺3,500 - ₺5,500',
      recentCampaigns: 15,
      verified: true,
      isActive: false,
      isBudgetFriendly: false
    },
    {
      id: 4,
      name: 'Can Polat',
      username: 'can_tech',
      avatar: 'https://images.pexels.com/photos/1239291/pexels-photo-1239291.jpeg?auto=compress&cs=tinysrgb&w=400',
      location: 'İstanbul',
      category: 'Teknoloji',
      followers: 12800,
      engagement: 9.1,
      avgLikes: 1100,
      avgComments: 78,
      rating: 4.6,
      priceRange: '₺2,200 - ₺3,800',
      recentCampaigns: 10,
      verified: true,
      isActive: true,
      isBudgetFriendly: true
    },
    {
      id: 5,
      name: 'Elif Kaya',
      username: 'elif_fitness',
      avatar: 'https://images.pexels.com/photos/1181690/pexels-photo-1181690.jpeg?auto=compress&cs=tinysrgb&w=400',
      location: 'Bursa',
      category: 'Fitness & Sağlık',
      followers: 18600,
      engagement: 7.9,
      avgLikes: 1380,
      avgComments: 92,
      rating: 4.8,
      priceRange: '₺2,800 - ₺4,200',
      recentCampaigns: 14,
      verified: false,
      isActive: true,
      isBudgetFriendly: false
    },
    {
      id: 6,
      name: 'Burak Şahin',
      username: 'burak_home',
      avatar: 'https://images.pexels.com/photos/1222271/pexels-photo-1222271.jpeg?auto=compress&cs=tinysrgb&w=400',
      location: 'Antalya',
      category: 'Ev & Dekorasyon',
      followers: 9200,
      engagement: 11.3,
      avgLikes: 890,
      avgComments: 156,
      rating: 4.9,
      priceRange: '₺1,900 - ₺3,100',
      recentCampaigns: 7,
      verified: true,
      isActive: true,
      isBudgetFriendly: true
    },
    {
      id: 7,
      name: 'Selin Özdemir',
      username: 'selin_anne',
      avatar: 'https://images.pexels.com/photos/1040880/pexels-photo-1040880.jpeg?auto=compress&cs=tinysrgb&w=400',
      location: 'İstanbul',
      category: 'Anne & Bebek',
      followers: 14200,
      engagement: 8.7,
      avgLikes: 1150,
      avgComments: 95,
      rating: 4.7,
      priceRange: '₺2,300 - ₺3,900',
      recentCampaigns: 11,
      verified: false,
      isActive: false,
      isBudgetFriendly: true
    },
    {
      id: 8,
      name: 'Emre Kılıç',
      username: 'emre_egitim',
      avatar: 'https://images.pexels.com/photos/1043474/pexels-photo-1043474.jpeg?auto=compress&cs=tinysrgb&w=400',
      location: 'Ankara',
      category: 'Eğitim',
      followers: 7800,
      engagement: 13.2,
      avgLikes: 890,
      avgComments: 167,
      rating: 4.8,
      priceRange: '₺1,500 - ₺2,800',
      recentCampaigns: 6,
      verified: true,
      isActive: true,
      isBudgetFriendly: true
    }
  ];

  // Filter influencers based on current filters
  useEffect(() => {
    let filtered = [...allInfluencers];

    if (filters) {
      // Search term filter
      if (filters.searchTerm) {
        const searchLower = filters.searchTerm.toLowerCase();
        filtered = filtered.filter(influencer => 
          influencer.name.toLowerCase().includes(searchLower) ||
          influencer.username.toLowerCase().includes(searchLower) ||
          influencer.category.toLowerCase().includes(searchLower)
        );
      }

      // Category filter
      if (filters.category) {
        filtered = filtered.filter(influencer => influencer.category === filters.category);
      }

      // Location filter
      if (filters.location) {
        filtered = filtered.filter(influencer => influencer.location === filters.location);
      }

      // Followers range filter
      if (filters.followersRange) {
        filtered = filtered.filter(influencer => {
          const followers = influencer.followers;
          switch (filters.followersRange) {
            case '1K-5K':
              return followers >= 1000 && followers <= 5000;
            case '5K-10K':
              return followers >= 5000 && followers <= 10000;
            case '10K-50K':
              return followers >= 10000 && followers <= 50000;
            case '50K+':
              return followers >= 50000;
            case '1K-10K':
              return followers >= 1000 && followers <= 10000;
            default:
              return true;
          }
        });
      }

      // Engagement range filter
      if (filters.engagementRange) {
        filtered = filtered.filter(influencer => {
          const engagement = influencer.engagement;
          switch (filters.engagementRange) {
            case '3-5':
              return engagement >= 3 && engagement <= 5;
            case '5-8':
              return engagement >= 5 && engagement <= 8;
            case '8-12':
              return engagement >= 8 && engagement <= 12;
            case '12+':
              return engagement >= 12;
            case '5+':
              return engagement >= 5;
            default:
              return true;
          }
        });
      }

      // Active filter
      if (filters.isActive) {
        filtered = filtered.filter(influencer => influencer.isActive);
      }

      // Budget friendly filter
      if (filters.isBudgetFriendly) {
        filtered = filtered.filter(influencer => influencer.isBudgetFriendly);
      }
    }

    setFilteredInfluencers(filtered);
  }, [filters]);

  // Initialize with all influencers
  useEffect(() => {
    if (!filters) {
      setFilteredInfluencers(allInfluencers);
    }
  }, []);

  const handleSort = (value: string) => {
    setSortBy(value);
  };

  const handleLoadMore = () => {
    // Simulate loading more influencers
    console.log('Loading more influencers...');
  };

  const handleViewProfile = (influencerId: number) => {
    if (onViewProfile) {
      onViewProfile(influencerId);
    } else {
      navigate(`/influencer/${influencerId}`);
    }
  };

  const getSortedInfluencers = () => {
    const sorted = [...filteredInfluencers];
    switch (sortBy) {
      case 'engagement':
        return sorted.sort((a, b) => b.engagement - a.engagement);
      case 'followers':
        return sorted.sort((a, b) => b.followers - a.followers);
      case 'rating':
        return sorted.sort((a, b) => b.rating - a.rating);
      case 'price-low':
        return sorted.sort((a, b) => {
          const aPrice = parseInt(a.priceRange.split(' - ')[0].replace('₺', '').replace(',', ''));
          const bPrice = parseInt(b.priceRange.split(' - ')[0].replace('₺', '').replace(',', ''));
          return aPrice - bPrice;
        });
      case 'price-high':
        return sorted.sort((a, b) => {
          const aPrice = parseInt(a.priceRange.split(' - ')[1].replace('₺', '').replace(',', ''));
          const bPrice = parseInt(b.priceRange.split(' - ')[1].replace('₺', '').replace(',', ''));
          return bPrice - aPrice;
        });
      default:
        return sorted;
    }
  };

  const sortedInfluencers = getSortedInfluencers();

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8 space-y-4 md:space-y-0">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">Öne Çıkan Etkileyiciler</h2>
          <p className="text-gray-600 mt-1">{sortedInfluencers.length} etkileyici bulundu</p>
        </div>
        <div className="flex items-center space-x-4">
          <div className="flex items-center space-x-2">
            <button
              onClick={() => setViewMode('grid')}
              className={`p-2 rounded-lg transition-colors ${
                viewMode === 'grid' ? 'bg-blue-100 text-blue-600' : 'text-gray-400 hover:text-gray-600'
              }`}
            >
              <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 20 20">
                <path d="M5 3a2 2 0 00-2 2v2a2 2 0 002 2h2a2 2 0 002-2V5a2 2 0 00-2-2H5zM5 11a2 2 0 00-2 2v2a2 2 0 002 2h2a2 2 0 002-2v-2a2 2 0 00-2-2H5zM11 5a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2V5zM11 13a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2v-2z" />
              </svg>
            </button>
            <button
              onClick={() => setViewMode('list')}
              className={`p-2 rounded-lg transition-colors ${
                viewMode === 'list' ? 'bg-blue-100 text-blue-600' : 'text-gray-400 hover:text-gray-600'
              }`}
            >
              <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 20 20">
                <path d="M3 4a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zM3 8a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zM3 12a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zM3 16a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1z" />
              </svg>
            </button>
          </div>
          <select 
            value={sortBy}
            onChange={(e) => handleSort(e.target.value)}
            className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          >
            <option value="recommended">Sırala: Önerilen</option>
            <option value="engagement">Etkileşim Oranı</option>
            <option value="followers">Takipçi Sayısı</option>
            <option value="price-low">Fiyat (Düşük-Yüksek)</option>
            <option value="price-high">Fiyat (Yüksek-Düşük)</option>
            <option value="rating">Puan (Yüksek-Düşük)</option>
          </select>
        </div>
      </div>

      {sortedInfluencers.length === 0 ? (
        <div className="text-center py-12">
          <div className="text-gray-400 mb-4">
            <svg className="w-16 h-16 mx-auto" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
            </svg>
          </div>
          <h3 className="text-lg font-medium text-gray-900 mb-2">Etkileyici bulunamadı</h3>
          <p className="text-gray-600">Arama kriterlerinizi değiştirmeyi deneyin.</p>
        </div>
      ) : (
        <>
          <div className={`${
            viewMode === 'grid' 
              ? 'grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6' 
              : 'space-y-4'
          }`}>
            {sortedInfluencers.map((influencer) => (
              <InfluencerCard 
                key={influencer.id} 
                influencer={influencer} 
                onViewProfile={handleViewProfile}
              />
            ))}
          </div>

          {/* Load More */}
          <div className="text-center mt-12">
            <button 
              onClick={handleLoadMore}
              className="bg-blue-800 text-white px-8 py-3 rounded-lg hover:bg-blue-900 transition-colors font-medium"
            >
              Daha Fazla Göster
            </button>
          </div>
        </>
      )}

      {/* Results Summary */}
      <div className="mt-8 text-center text-sm text-gray-500">
        Gösterilen: {sortedInfluencers.length} etkileyici • Toplam: {allInfluencers.length}+ etkileyici
      </div>
    </div>
  );
};

export default InfluencerGrid;