import React, { useState } from 'react';
import { Search, Filter, MapPin, Users, TrendingUp, Sliders } from 'lucide-react';

interface SearchFiltersProps {
  onFiltersChange: (filters: FilterState) => void;
}

interface FilterState {
  searchTerm: string;
  category: string;
  location: string;
  followersRange: string;
  engagementRange: string;
  isActive: boolean;
  isBudgetFriendly: boolean;
}

const SearchFilters: React.FC<SearchFiltersProps> = ({ onFiltersChange }) => {
  const [filters, setFilters] = useState<FilterState>({
    searchTerm: '',
    category: '',
    location: '',
    followersRange: '',
    engagementRange: '',
    isActive: false,
    isBudgetFriendly: false
  });
  const [showAdvancedFilters, setShowAdvancedFilters] = useState(false);

  const categories = [
    'Moda & Güzellik', 'Yemek & Mutfak', 'Teknoloji', 'Seyahat', 
    'Fitness & Sağlık', 'Anne & Bebek', 'Ev & Dekorasyon', 'Eğitim'
  ];

  const locations = [
    'İstanbul', 'Ankara', 'İzmir', 'Bursa', 'Antalya', 'Adana', 'Konya', 'Gaziantep'
  ];

  const updateFilters = (newFilters: Partial<FilterState>) => {
    const updatedFilters = { ...filters, ...newFilters };
    setFilters(updatedFilters);
    onFiltersChange(updatedFilters);
  };

  const handleSearch = () => {
    onFiltersChange(filters);
  };

  const handleQuickFilter = (type: 'followers' | 'engagement' | 'active' | 'budget', value?: string) => {
    if (type === 'followers') {
      const newValue = filters.followersRange === value ? '' : value || '';
      updateFilters({ followersRange: newValue });
    } else if (type === 'engagement') {
      const newValue = filters.engagementRange === value ? '' : value || '';
      updateFilters({ engagementRange: newValue });
    } else if (type === 'active') {
      updateFilters({ isActive: !filters.isActive });
    } else if (type === 'budget') {
      updateFilters({ isBudgetFriendly: !filters.isBudgetFriendly });
    }
  };

  const clearAllFilters = () => {
    const clearedFilters: FilterState = {
      searchTerm: '',
      category: '',
      location: '',
      followersRange: '',
      engagementRange: '',
      isActive: false,
      isBudgetFriendly: false
    };
    setFilters(clearedFilters);
    setShowAdvancedFilters(false);
    onFiltersChange(clearedFilters);
  };

  const hasActiveFilters = Object.values(filters).some(value => 
    typeof value === 'string' ? value !== '' : value === true
  );

  return (
    <div className="bg-white shadow-lg rounded-2xl p-6 mx-4 -mt-16 relative z-10 max-w-6xl mx-auto">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
        {/* Search */}
        <div className="lg:col-span-2">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
            <input
              type="text"
              placeholder="Etkileyici ara..."
              value={filters.searchTerm}
              onChange={(e) => updateFilters({ searchTerm: e.target.value })}
              className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>
        </div>

        {/* Category */}
        <div>
          <select 
            value={filters.category}
            onChange={(e) => updateFilters({ category: e.target.value })}
            className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          >
            <option value="">Kategori</option>
            {categories.map((category) => (
              <option key={category} value={category}>{category}</option>
            ))}
          </select>
        </div>

        {/* Location */}
        <div>
          <div className="relative">
            <MapPin className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
            <select 
              value={filters.location}
              onChange={(e) => updateFilters({ location: e.target.value })}
              className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            >
              <option value="">Konum</option>
              {locations.map((location) => (
                <option key={location} value={location}>{location}</option>
              ))}
            </select>
          </div>
        </div>

        {/* Search Button */}
        <div>
          <button 
            onClick={handleSearch}
            className="w-full bg-blue-800 text-white px-4 py-3 rounded-xl hover:bg-blue-900 transition-colors flex items-center justify-center space-x-2"
          >
            <Search className="w-5 h-5" />
            <span>Ara</span>
          </button>
        </div>
      </div>

      {/* Advanced Filters Toggle */}
      <div className="flex justify-between items-center mt-4">
        <div className="flex flex-wrap gap-2">
          <span className="text-sm text-gray-600 mr-2">Hızlı Filtre:</span>
          <button 
            onClick={() => handleQuickFilter('followers', '1K-10K')}
            className={`px-3 py-1 rounded-full text-sm transition-colors ${
              filters.followersRange === '1K-10K' 
                ? 'bg-blue-500 text-white' 
                : 'bg-blue-100 text-blue-800 hover:bg-blue-200'
            }`}
          >
            1K-10K Takipçi
          </button>
          <button 
            onClick={() => handleQuickFilter('engagement', '5+')}
            className={`px-3 py-1 rounded-full text-sm transition-colors ${
              filters.engagementRange === '5+' 
                ? 'bg-green-500 text-white' 
                : 'bg-green-100 text-green-800 hover:bg-green-200'
            }`}
          >
            %5+ Etkileşim
          </button>
          <button 
            onClick={() => handleQuickFilter('active')}
            className={`px-3 py-1 rounded-full text-sm transition-colors ${
              filters.isActive 
                ? 'bg-purple-500 text-white' 
                : 'bg-purple-100 text-purple-800 hover:bg-purple-200'
            }`}
          >
            Son 30 Gün Aktif
          </button>
          <button 
            onClick={() => handleQuickFilter('budget')}
            className={`px-3 py-1 rounded-full text-sm transition-colors ${
              filters.isBudgetFriendly 
                ? 'bg-orange-500 text-white' 
                : 'bg-orange-100 text-orange-800 hover:bg-orange-200'
            }`}
          >
            Bütçe Dostu
          </button>
          {hasActiveFilters && (
            <button 
              onClick={clearAllFilters}
              className="px-3 py-1 bg-red-100 text-red-800 rounded-full text-sm hover:bg-red-200 transition-colors"
            >
              Filtreleri Temizle
            </button>
          )}
        </div>
        
        <button 
          onClick={() => setShowAdvancedFilters(!showAdvancedFilters)}
          className="flex items-center space-x-2 text-gray-600 hover:text-gray-800 transition-colors"
        >
          <Sliders className="w-4 h-4" />
          <span className="text-sm">Gelişmiş Filtreler</span>
        </button>
      </div>

      {/* Advanced Filters Panel */}
      {showAdvancedFilters && (
        <div className="mt-6 p-4 bg-gray-50 rounded-xl border border-gray-200">
          <h3 className="font-semibold text-gray-900 mb-4">Gelişmiş Filtreler</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Takipçi Aralığı
              </label>
              <select 
                value={filters.followersRange}
                onChange={(e) => updateFilters({ followersRange: e.target.value })}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              >
                <option value="">Seçin</option>
                <option value="1K-5K">1K - 5K</option>
                <option value="5K-10K">5K - 10K</option>
                <option value="10K-50K">10K - 50K</option>
                <option value="50K+">50K+</option>
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Etkileşim Oranı
              </label>
              <select 
                value={filters.engagementRange}
                onChange={(e) => updateFilters({ engagementRange: e.target.value })}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              >
                <option value="">Seçin</option>
                <option value="3-5">%3 - %5</option>
                <option value="5-8">%5 - %8</option>
                <option value="8-12">%8 - %12</option>
                <option value="12+">%12+</option>
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Bütçe Aralığı
              </label>
              <select className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                <option value="">Seçin</option>
                <option value="500-1500">₺500 - ₺1,500</option>
                <option value="1500-3000">₺1,500 - ₺3,000</option>
                <option value="3000-5000">₺3,000 - ₺5,000</option>
                <option value="5000+">₺5,000+</option>
              </select>
            </div>
          </div>
          <div className="flex justify-end mt-4 space-x-2">
            <button 
              onClick={() => setShowAdvancedFilters(false)}
              className="px-4 py-2 text-gray-600 hover:text-gray-800 transition-colors"
            >
              İptal
            </button>
            <button 
              onClick={() => {
                onFiltersChange(filters);
                setShowAdvancedFilters(false);
              }}
              className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
            >
              Filtreleri Uygula
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default SearchFilters;