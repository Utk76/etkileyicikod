import React, { useState } from 'react';
import { 
  BarChart3, Users, MessageCircle, Heart, Star, Settings, 
  CreditCard, FileText, Calendar, TrendingUp, MapPin, 
  Filter, Search, Bell, Download, Eye, Share2, ArrowUp, ArrowDown
} from 'lucide-react';

interface Campaign {
  id: number;
  name: string;
  status: 'active' | 'completed' | 'draft';
  influencers: number;
  budget: number;
  reach: number;
  engagement: number;
  startDate: string;
  endDate: string;
}

interface Contact {
  id: number;
  name: string;
  username: string;
  avatar: string;
  lastMessage: string;
  timestamp: string;
  unread: boolean;
}

interface Favorite {
  id: number;
  name: string;
  username: string;
  avatar: string;
  category: string;
  followers: number;
  engagement: number;
}

interface Subscription {
  packageName: string;
  price: number;
  billingCycle: 'monthly' | 'quarterly';
  nextBilling: string;
  status: 'active' | 'trial' | 'expired';
  trialDaysLeft?: number;
  features: string[];
  usage: {
    profileViews: { used: number; limit: number };
    contacts: { used: number; limit: number };
  };
}

const UserDashboard = () => {
  const [activeTab, setActiveTab] = useState('overview');
  const [subscription, setSubscription] = useState<Subscription>({
    packageName: 'Büyüyen İşletme',
    price: 1499,
    billingCycle: 'monthly',
    nextBilling: '2024-02-15',
    status: 'active',
    features: [
      '3 Ayda 20 Profil Görüntüleme',
      'Etkileşim Oranı Analizi',
      'Gelişmiş Filtreleme',
      '3 Ayda 20 İletişim Hakkı'
    ],
    usage: {
      profileViews: { used: 15, limit: 20 },
      contacts: { used: 12, limit: 20 }
    }
  });

  // Mock data
  const campaigns: Campaign[] = [
    {
      id: 1,
      name: 'Yaz Koleksiyonu Lansmanı',
      status: 'active',
      influencers: 5,
      budget: 15000,
      reach: 125000,
      engagement: 8.5,
      startDate: '2024-01-15',
      endDate: '2024-02-15'
    },
    {
      id: 2,
      name: 'Organik Ürün Tanıtımı',
      status: 'completed',
      influencers: 3,
      budget: 8500,
      reach: 85000,
      engagement: 12.3,
      startDate: '2023-12-01',
      endDate: '2023-12-31'
    }
  ];

  const contacts: Contact[] = [
    {
      id: 1,
      name: 'Ayşe Demir',
      username: 'aysedemir_style',
      avatar: 'https://images.pexels.com/photos/1036623/pexels-photo-1036623.jpeg?auto=compress&cs=tinysrgb&w=400',
      lastMessage: 'Kampanya detaylarını gönderebilir misiniz?',
      timestamp: '2 saat önce',
      unread: true
    },
    {
      id: 2,
      name: 'Mehmet Özkan',
      username: 'mehmet_foodie',
      avatar: 'https://images.pexels.com/photos/1043471/pexels-photo-1043471.jpeg?auto=compress&cs=tinysrgb&w=400',
      lastMessage: 'Teşekkürler, çok güzel bir iş birliği oldu.',
      timestamp: '1 gün önce',
      unread: false
    }
  ];

  const favorites: Favorite[] = [
    {
      id: 1,
      name: 'Zeynep Yılmaz',
      username: 'zeynep_travels',
      avatar: 'https://images.pexels.com/photos/1130626/pexels-photo-1130626.jpeg?auto=compress&cs=tinysrgb&w=400',
      category: 'Seyahat',
      followers: 22100,
      engagement: 6.8
    },
    {
      id: 2,
      name: 'Can Polat',
      username: 'can_tech',
      avatar: 'https://images.pexels.com/photos/1239291/pexels-photo-1239291.jpeg?auto=compress&cs=tinysrgb&w=400',
      category: 'Teknoloji',
      followers: 12800,
      engagement: 9.1
    }
  ];

  const formatNumber = (num: number) => {
    if (num >= 1000000) return `${(num / 1000000).toFixed(1)}M`;
    if (num >= 1000) return `${(num / 1000).toFixed(1)}K`;
    return num.toString();
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active': return 'bg-green-100 text-green-800';
      case 'completed': return 'bg-blue-100 text-blue-800';
      case 'draft': return 'bg-gray-100 text-gray-800';
      case 'trial': return 'bg-yellow-100 text-yellow-800';
      case 'expired': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'active': return 'Aktif';
      case 'completed': return 'Tamamlandı';
      case 'draft': return 'Taslak';
      case 'trial': return 'Deneme';
      case 'expired': return 'Süresi Doldu';
      default: return status;
    }
  };

  const handlePackageChange = (direction: 'upgrade' | 'downgrade') => {
    const packages = [
      { name: 'Temel İşletme', price: 499 },
      { name: 'Büyüyen İşletme', price: 1499 },
      { name: 'Kurumsal', price: 3499 }
    ];
    
    const currentIndex = packages.findIndex(p => p.name === subscription.packageName);
    let newIndex = currentIndex;
    
    if (direction === 'upgrade' && currentIndex < packages.length - 1) {
      newIndex = currentIndex + 1;
    } else if (direction === 'downgrade' && currentIndex > 0) {
      newIndex = currentIndex - 1;
    }
    
    if (newIndex !== currentIndex) {
      setSubscription({
        ...subscription,
        packageName: packages[newIndex].name,
        price: packages[newIndex].price
      });
      alert(`Paket değişikliği başarılı! Yeni paket: ${packages[newIndex].name}\nDeğişiklik bir sonraki fatura döneminde geçerli olacak.`);
    }
  };

  const handleCancelSubscription = () => {
    if (confirm('Aboneliğinizi iptal etmek istediğinizden emin misiniz? Mevcut dönem sonuna kadar hizmetiniz devam edecek.')) {
      alert('Aboneliğiniz başarıyla iptal edildi. Mevcut dönem sonuna kadar hizmetiniz devam edecek.');
    }
  };

  console.log('✅ [UserDashboard with Subscription Management] tamamlandı');

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center">
              <div className="w-8 h-8 bg-gradient-to-br from-blue-800 to-orange-600 rounded-lg flex items-center justify-center">
                <span className="text-white font-bold text-sm">Mİ</span>
              </div>
              <span className="ml-2 text-xl font-bold text-gray-900">MikroEtki</span>
            </div>
            <div className="flex items-center space-x-4">
              <button className="text-gray-500 hover:text-gray-700 transition-colors relative">
                <Bell className="w-5 h-5" />
                <span className="absolute -top-1 -right-1 w-3 h-3 bg-red-500 rounded-full"></span>
              </button>
              <div className="flex items-center space-x-2">
                <img
                  src="https://images.pexels.com/photos/1681010/pexels-photo-1681010.jpeg?auto=compress&cs=tinysrgb&w=400"
                  alt="Profile"
                  className="w-8 h-8 rounded-full object-cover"
                />
                <span className="text-sm font-medium text-gray-700">Ahmet Yılmaz</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex flex-col lg:flex-row gap-8">
          {/* Sidebar */}
          <div className="lg:w-64 flex-shrink-0">
            <div className="bg-white rounded-2xl shadow-sm border border-gray-200 p-6">
              <nav className="space-y-2">
                <button
                  onClick={() => setActiveTab('overview')}
                  className={`w-full flex items-center space-x-3 px-4 py-3 rounded-xl text-left transition-colors ${
                    activeTab === 'overview' 
                      ? 'bg-blue-50 text-blue-700 border border-blue-200' 
                      : 'text-gray-700 hover:bg-gray-50'
                  }`}
                >
                  <BarChart3 className="w-5 h-5" />
                  <span>Genel Bakış</span>
                </button>
                <button
                  onClick={() => setActiveTab('campaigns')}
                  className={`w-full flex items-center space-x-3 px-4 py-3 rounded-xl text-left transition-colors ${
                    activeTab === 'campaigns' 
                      ? 'bg-blue-50 text-blue-700 border border-blue-200' 
                      : 'text-gray-700 hover:bg-gray-50'
                  }`}
                >
                  <Calendar className="w-5 h-5" />
                  <span>Kampanyalarım</span>
                </button>
                <button
                  onClick={() => setActiveTab('contacts')}
                  className={`w-full flex items-center space-x-3 px-4 py-3 rounded-xl text-left transition-colors ${
                    activeTab === 'contacts' 
                      ? 'bg-blue-50 text-blue-700 border border-blue-200' 
                      : 'text-gray-700 hover:bg-gray-50'
                  }`}
                >
                  <MessageCircle className="w-5 h-5" />
                  <span>İletişim Geçtiklerim</span>
                </button>
                <button
                  onClick={() => setActiveTab('favorites')}
                  className={`w-full flex items-center space-x-3 px-4 py-3 rounded-xl text-left transition-colors ${
                    activeTab === 'favorites' 
                      ? 'bg-blue-50 text-blue-700 border border-blue-200' 
                      : 'text-gray-700 hover:bg-gray-50'
                  }`}
                >
                  <Heart className="w-5 h-5" />
                  <span>Favori Etkileyiciler</span>
                </button>
                <button
                  onClick={() => setActiveTab('subscription')}
                  className={`w-full flex items-center space-x-3 px-4 py-3 rounded-xl text-left transition-colors ${
                    activeTab === 'subscription' 
                      ? 'bg-blue-50 text-blue-700 border border-blue-200' 
                      : 'text-gray-700 hover:bg-gray-50'
                  }`}
                >
                  <CreditCard className="w-5 h-5" />
                  <span>Abonelik Yönetimi</span>
                </button>
                <button
                  onClick={() => setActiveTab('billing')}
                  className={`w-full flex items-center space-x-3 px-4 py-3 rounded-xl text-left transition-colors ${
                    activeTab === 'billing' 
                      ? 'bg-blue-50 text-blue-700 border border-blue-200' 
                      : 'text-gray-700 hover:bg-gray-50'
                  }`}
                >
                  <FileText className="w-5 h-5" />
                  <span>Ödeme Geçmişi</span>
                </button>
                <button
                  onClick={() => setActiveTab('settings')}
                  className={`w-full flex items-center space-x-3 px-4 py-3 rounded-xl text-left transition-colors ${
                    activeTab === 'settings' 
                      ? 'bg-blue-50 text-blue-700 border border-blue-200' 
                      : 'text-gray-700 hover:bg-gray-50'
                  }`}
                >
                  <Settings className="w-5 h-5" />
                  <span>Ayarlar</span>
                </button>
              </nav>
            </div>
          </div>

          {/* Main Content */}
          <div className="flex-1">
            {activeTab === 'overview' && (
              <div className="space-y-8">
                <div>
                  <h1 className="text-3xl font-bold text-gray-900 mb-2">Genel Bakış</h1>
                  <p className="text-gray-600">Hesabınızın genel durumu ve performans metrikleri</p>
                </div>

                {/* Stats Cards */}
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                  <div className="bg-white rounded-2xl p-6 shadow-sm border border-gray-200">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm text-gray-600">Aktif Kampanyalar</p>
                        <p className="text-2xl font-bold text-gray-900">3</p>
                      </div>
                      <div className="w-12 h-12 bg-blue-100 rounded-xl flex items-center justify-center">
                        <Calendar className="w-6 h-6 text-blue-600" />
                      </div>
                    </div>
                  </div>
                  <div className="bg-white rounded-2xl p-6 shadow-sm border border-gray-200">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm text-gray-600">Toplam Erişim</p>
                        <p className="text-2xl font-bold text-gray-900">210K</p>
                      </div>
                      <div className="w-12 h-12 bg-green-100 rounded-xl flex items-center justify-center">
                        <Users className="w-6 h-6 text-green-600" />
                      </div>
                    </div>
                  </div>
                  <div className="bg-white rounded-2xl p-6 shadow-sm border border-gray-200">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm text-gray-600">Ortalama Etkileşim</p>
                        <p className="text-2xl font-bold text-gray-900">9.2%</p>
                      </div>
                      <div className="w-12 h-12 bg-orange-100 rounded-xl flex items-center justify-center">
                        <TrendingUp className="w-6 h-6 text-orange-600" />
                      </div>
                    </div>
                  </div>
                  <div className="bg-white rounded-2xl p-6 shadow-sm border border-gray-200">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm text-gray-600">Toplam Harcama</p>
                        <p className="text-2xl font-bold text-gray-900">₺23.5K</p>
                      </div>
                      <div className="w-12 h-12 bg-purple-100 rounded-xl flex items-center justify-center">
                        <CreditCard className="w-6 h-6 text-purple-600" />
                      </div>
                    </div>
                  </div>
                </div>

                {/* Usage Overview */}
                <div className="bg-white rounded-2xl shadow-sm border border-gray-200 p-6">
                  <h2 className="text-xl font-semibold text-gray-900 mb-6">Paket Kullanımı</h2>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <div className="flex justify-between items-center mb-2">
                        <span className="text-gray-600">Profil Görüntüleme</span>
                        <span className="font-semibold text-gray-900">
                          {subscription.usage.profileViews.used}/{subscription.usage.profileViews.limit}
                        </span>
                      </div>
                      <div className="w-full bg-gray-200 rounded-full h-2">
                        <div 
                          className="bg-blue-600 h-2 rounded-full"
                          style={{ width: `${(subscription.usage.profileViews.used / subscription.usage.profileViews.limit) * 100}%` }}
                        ></div>
                      </div>
                    </div>
                    <div>
                      <div className="flex justify-between items-center mb-2">
                        <span className="text-gray-600">İletişim Hakkı</span>
                        <span className="font-semibold text-gray-900">
                          {subscription.usage.contacts.used}/{subscription.usage.contacts.limit}
                        </span>
                      </div>
                      <div className="w-full bg-gray-200 rounded-full h-2">
                        <div 
                          className="bg-green-600 h-2 rounded-full"
                          style={{ width: `${(subscription.usage.contacts.used / subscription.usage.contacts.limit) * 100}%` }}
                        ></div>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Recent Activity */}
                <div className="bg-white rounded-2xl shadow-sm border border-gray-200 p-6">
                  <h2 className="text-xl font-semibold text-gray-900 mb-6">Son Aktiviteler</h2>
                  <div className="space-y-4">
                    <div className="flex items-center space-x-4 p-4 bg-gray-50 rounded-xl">
                      <div className="w-10 h-10 bg-green-100 rounded-full flex items-center justify-center">
                        <Calendar className="w-5 h-5 text-green-600" />
                      </div>
                      <div className="flex-1">
                        <p className="font-medium text-gray-900">Yeni kampanya başlatıldı</p>
                        <p className="text-sm text-gray-600">Yaz Koleksiyonu Lansmanı - 2 saat önce</p>
                      </div>
                    </div>
                    <div className="flex items-center space-x-4 p-4 bg-gray-50 rounded-xl">
                      <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
                        <MessageCircle className="w-5 h-5 text-blue-600" />
                      </div>
                      <div className="flex-1">
                        <p className="font-medium text-gray-900">Yeni mesaj alındı</p>
                        <p className="text-sm text-gray-600">Ayşe Demir'den - 3 saat önce</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {activeTab === 'campaigns' && (
              <div className="space-y-8">
                <div className="flex justify-between items-center">
                  <div>
                    <h1 className="text-3xl font-bold text-gray-900 mb-2">Kampanyalarım</h1>
                    <p className="text-gray-600">Tüm kampanyalarınızı yönetin ve takip edin</p>
                  </div>
                  <button className="bg-blue-600 text-white px-6 py-3 rounded-xl hover:bg-blue-700 transition-colors">
                    Yeni Kampanya
                  </button>
                </div>

                <div className="space-y-6">
                  {campaigns.map((campaign) => (
                    <div key={campaign.id} className="bg-white rounded-2xl shadow-sm border border-gray-200 p-6">
                      <div className="flex justify-between items-start mb-4">
                        <div>
                          <h3 className="text-xl font-semibold text-gray-900 mb-2">{campaign.name}</h3>
                          <span className={`px-3 py-1 rounded-full text-sm font-medium ${getStatusColor(campaign.status)}`}>
                            {getStatusText(campaign.status)}
                          </span>
                        </div>
                        <div className="flex space-x-2">
                          <button className="p-2 text-gray-400 hover:text-gray-600 transition-colors">
                            <Eye className="w-5 h-5" />
                          </button>
                          <button className="p-2 text-gray-400 hover:text-gray-600 transition-colors">
                            <Download className="w-5 h-5" />
                          </button>
                        </div>
                      </div>
                      
                      <div className="grid grid-cols-2 md:grid-cols-5 gap-4 mb-4">
                        <div>
                          <p className="text-sm text-gray-600">Etkileyici Sayısı</p>
                          <p className="font-semibold text-gray-900">{campaign.influencers}</p>
                        </div>
                        <div>
                          <p className="text-sm text-gray-600">Bütçe</p>
                          <p className="font-semibold text-gray-900">₺{campaign.budget.toLocaleString('tr-TR')}</p>
                        </div>
                        <div>
                          <p className="text-sm text-gray-600">Erişim</p>
                          <p className="font-semibold text-gray-900">{formatNumber(campaign.reach)}</p>
                        </div>
                        <div>
                          <p className="text-sm text-gray-600">Etkileşim</p>
                          <p className="font-semibold text-gray-900">%{campaign.engagement}</p>
                        </div>
                        <div>
                          <p className="text-sm text-gray-600">Süre</p>
                          <p className="font-semibold text-gray-900">{campaign.startDate} - {campaign.endDate}</p>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {activeTab === 'contacts' && (
              <div className="space-y-8">
                <div>
                  <h1 className="text-3xl font-bold text-gray-900 mb-2">İletişim Geçtiklerim</h1>
                  <p className="text-gray-600">Etkileyicilerle mesajlaşma geçmişiniz</p>
                </div>

                <div className="bg-white rounded-2xl shadow-sm border border-gray-200">
                  <div className="p-6 border-b border-gray-200">
                    <div className="relative">
                      <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                      <input
                        type="text"
                        placeholder="Etkileyici ara..."
                        className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                      />
                    </div>
                  </div>
                  
                  <div className="divide-y divide-gray-200">
                    {contacts.map((contact) => (
                      <div key={contact.id} className="p-6 hover:bg-gray-50 transition-colors cursor-pointer">
                        <div className="flex items-center space-x-4">
                          <div className="relative">
                            <img
                              src={contact.avatar}
                              alt={contact.name}
                              className="w-12 h-12 rounded-full object-cover"
                            />
                            {contact.unread && (
                              <div className="absolute -top-1 -right-1 w-4 h-4 bg-blue-500 rounded-full"></div>
                            )}
                          </div>
                          <div className="flex-1">
                            <div className="flex justify-between items-start">
                              <div>
                                <h3 className="font-semibold text-gray-900">{contact.name}</h3>
                                <p className="text-sm text-gray-500">@{contact.username}</p>
                              </div>
                              <span className="text-xs text-gray-500">{contact.timestamp}</span>
                            </div>
                            <p className={`text-sm mt-1 ${contact.unread ? 'font-medium text-gray-900' : 'text-gray-600'}`}>
                              {contact.lastMessage}
                            </p>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {activeTab === 'favorites' && (
              <div className="space-y-8">
                <div>
                  <h1 className="text-3xl font-bold text-gray-900 mb-2">Favori Etkileyiciler</h1>
                  <p className="text-gray-600">Beğendiğiniz etkileyicileri kaydedin</p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {favorites.map((favorite) => (
                    <div key={favorite.id} className="bg-white rounded-2xl shadow-sm border border-gray-200 p-6">
                      <div className="flex items-center space-x-4 mb-4">
                        <img
                          src={favorite.avatar}
                          alt={favorite.name}
                          className="w-16 h-16 rounded-full object-cover"
                        />
                        <div className="flex-1">
                          <h3 className="font-semibold text-gray-900">{favorite.name}</h3>
                          <p className="text-sm text-gray-500">@{favorite.username}</p>
                          <span className="inline-block px-2 py-1 bg-gray-100 rounded-full text-xs text-gray-600 mt-1">
                            {favorite.category}
                          </span>
                        </div>
                        <button className="p-2 text-red-500 hover:text-red-600 transition-colors">
                          <Heart className="w-5 h-5 fill-current" />
                        </button>
                      </div>
                      
                      <div className="grid grid-cols-2 gap-4 mb-4">
                        <div>
                          <p className="text-sm text-gray-600">Takipçi</p>
                          <p className="font-semibold text-gray-900">{formatNumber(favorite.followers)}</p>
                        </div>
                        <div>
                          <p className="text-sm text-gray-600">Etkileşim</p>
                          <p className="font-semibold text-gray-900">%{favorite.engagement}</p>
                        </div>
                      </div>
                      
                      <button className="w-full bg-blue-600 text-white py-2 rounded-lg hover:bg-blue-700 transition-colors">
                        İletişime Geç
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {activeTab === 'subscription' && (
              <div className="space-y-8">
                <div>
                  <h1 className="text-3xl font-bold text-gray-900 mb-2">Abonelik Yönetimi</h1>
                  <p className="text-gray-600">Mevcut paketinizi yönetin ve değiştirin</p>
                </div>

                {/* Current Plan */}
                <div className="bg-white rounded-2xl shadow-sm border border-gray-200 p-6">
                  <div className="flex justify-between items-start mb-6">
                    <div>
                      <h2 className="text-xl font-semibold text-gray-900 mb-2">Mevcut Paketiniz</h2>
                      <div className="flex items-center space-x-4">
                        <span className="text-2xl font-bold text-orange-600">{subscription.packageName}</span>
                        <span className={`px-3 py-1 rounded-full text-sm font-medium ${getStatusColor(subscription.status)}`}>
                          {getStatusText(subscription.status)}
                        </span>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="text-2xl font-bold text-gray-900">₺{subscription.price.toLocaleString('tr-TR')}/ay</p>
                      <p className="text-sm text-gray-600">Sonraki ödeme: {subscription.nextBilling}</p>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                    <div className="text-center p-4 bg-gray-50 rounded-xl">
                      <p className="text-2xl font-bold text-gray-900">
                        {subscription.usage.profileViews.limit - subscription.usage.profileViews.used}
                      </p>
                      <p className="text-sm text-gray-600">Kalan Profil Görüntüleme</p>
                    </div>
                    <div className="text-center p-4 bg-gray-50 rounded-xl">
                      <p className="text-2xl font-bold text-gray-900">
                        {subscription.usage.contacts.limit - subscription.usage.contacts.used}
                      </p>
                      <p className="text-sm text-gray-600">Kalan İletişim Hakkı</p>
                    </div>
                  </div>

                  <div className="flex flex-col sm:flex-row space-y-2 sm:space-y-0 sm:space-x-4">
                    <button 
                      onClick={() => handlePackageChange('upgrade')}
                      className="flex-1 bg-blue-600 text-white py-3 rounded-xl hover:bg-blue-700 transition-colors flex items-center justify-center space-x-2"
                    >
                      <ArrowUp className="w-4 h-4" />
                      <span>Paketi Yükselt</span>
                    </button>
                    <button 
                      onClick={() => handlePackageChange('downgrade')}
                      className="flex-1 border border-gray-300 text-gray-700 py-3 rounded-xl hover:bg-gray-50 transition-colors flex items-center justify-center space-x-2"
                    >
                      <ArrowDown className="w-4 h-4" />
                      <span>Paketi Düşür</span>
                    </button>
                    <button 
                      onClick={handleCancelSubscription}
                      className="px-6 border border-red-300 text-red-600 py-3 rounded-xl hover:bg-red-50 transition-colors"
                    >
                      İptal Et
                    </button>
                  </div>
                </div>

                {/* Package Features */}
                <div className="bg-white rounded-2xl shadow-sm border border-gray-200 p-6">
                  <h2 className="text-lg font-semibold text-gray-900 mb-4">Paket Özellikleri</h2>
                  <div className="space-y-3">
                    {subscription.features.map((feature, index) => (
                      <div key={index} className="flex items-center space-x-3">
                        <div className="w-5 h-5 bg-green-100 rounded-full flex items-center justify-center">
                          <div className="w-2 h-2 bg-green-600 rounded-full"></div>
                        </div>
                        <span className="text-gray-700">{feature}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {activeTab === 'billing' && (
              <div className="space-y-8">
                <div>
                  <h1 className="text-3xl font-bold text-gray-900 mb-2">Ödeme Geçmişi</h1>
                  <p className="text-gray-600">Tüm faturalarınızı görüntüleyin ve indirin</p>
                </div>

                {/* Payment Methods */}
                <div className="bg-white rounded-2xl shadow-sm border border-gray-200 p-6 mb-6">
                  <h2 className="text-lg font-semibold text-gray-900 mb-4">Ödeme Yöntemleri</h2>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div className="border border-gray-200 rounded-xl p-4 text-center">
                      <CreditCard className="w-8 h-8 mx-auto mb-2 text-blue-600" />
                      <h3 className="font-medium text-gray-900">Kredi Kartı</h3>
                      <p className="text-sm text-gray-600">Visa, Mastercard</p>
                    </div>
                    <div className="border border-gray-200 rounded-xl p-4 text-center">
                      <FileText className="w-8 h-8 mx-auto mb-2 text-green-600" />
                      <h3 className="font-medium text-gray-900">Banka Kartı</h3>
                      <p className="text-sm text-gray-600">Debit kartlar</p>
                    </div>
                    <div className="border border-gray-200 rounded-xl p-4 text-center">
                      <Users className="w-8 h-8 mx-auto mb-2 text-purple-600" />
                      <h3 className="font-medium text-gray-900">Havale/EFT</h3>
                      <p className="text-sm text-gray-600">Banka transferi</p>
                    </div>
                  </div>
                  <div className="mt-4 p-4 bg-green-50 rounded-xl">
                    <div className="flex items-center space-x-2">
                      <Shield className="w-5 h-5 text-green-600" />
                      <span className="text-green-800 font-medium">SSL Güvenlik</span>
                    </div>
                    <p className="text-sm text-green-700 mt-1">
                      Tüm ödeme bilgileriniz 256-bit SSL şifreleme ile korunur
                    </p>
                  </div>
                </div>

                <div className="bg-white rounded-2xl shadow-sm border border-gray-200">
                  <div className="p-6 border-b border-gray-200">
                    <div className="flex justify-between items-center">
                      <h2 className="text-lg font-semibold text-gray-900">Faturalar</h2>
                      <button className="text-blue-600 hover:text-blue-700 transition-colors">
                        Tümünü İndir
                      </button>
                    </div>
                  </div>
                  
                  <div className="divide-y divide-gray-200">
                    {[
                      { date: '15 Ocak 2024', amount: '₺1,499', status: 'Ödendi', invoice: 'INV-2024-001' },
                      { date: '15 Aralık 2023', amount: '₺1,499', status: 'Ödendi', invoice: 'INV-2023-012' },
                      { date: '15 Kasım 2023', amount: '₺1,499', status: 'Ödendi', invoice: 'INV-2023-011' }
                    ].map((bill, index) => (
                      <div key={index} className="p-6 flex justify-between items-center">
                        <div>
                          <p className="font-medium text-gray-900">{bill.invoice}</p>
                          <p className="text-sm text-gray-600">{bill.date}</p>
                        </div>
                        <div className="text-right">
                          <p className="font-semibold text-gray-900">{bill.amount}</p>
                          <span className="px-2 py-1 bg-green-100 text-green-800 rounded-full text-xs">
                            {bill.status}
                          </span>
                        </div>
                        <button className="text-blue-600 hover:text-blue-700 transition-colors">
                          <Download className="w-5 h-5" />
                        </button>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {activeTab === 'settings' && (
              <div className="space-y-8">
                <div>
                  <h1 className="text-3xl font-bold text-gray-900 mb-2">Hesap Ayarları</h1>
                  <p className="text-gray-600">Profil bilgilerinizi ve tercihlerinizi yönetin</p>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                  {/* Profile Settings */}
                  <div className="bg-white rounded-2xl shadow-sm border border-gray-200 p-6">
                    <h2 className="text-lg font-semibold text-gray-900 mb-6">Profil Bilgileri</h2>
                    <div className="space-y-4">
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">
                          Şirket Adı
                        </label>
                        <input
                          type="text"
                          defaultValue="Organic Foods İstanbul"
                          className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">
                          E-posta
                        </label>
                        <input
                          type="email"
                          defaultValue="ahmet@organicfoods.com"
                          className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">
                          Telefon
                        </label>
                        <input
                          type="tel"
                          defaultValue="+90 532 123 45 67"
                          className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                        />
                      </div>
                      <button className="w-full bg-blue-600 text-white py-3 rounded-xl hover:bg-blue-700 transition-colors">
                        Değişiklikleri Kaydet
                      </button>
                    </div>
                  </div>

                  {/* Notification Settings */}
                  <div className="bg-white rounded-2xl shadow-sm border border-gray-200 p-6">
                    <h2 className="text-lg font-semibold text-gray-900 mb-6">Bildirim Tercihleri</h2>
                    <div className="space-y-4">
                      <div className="flex justify-between items-center">
                        <div>
                          <p className="font-medium text-gray-900">E-posta Bildirimleri</p>
                          <p className="text-sm text-gray-600">Yeni mesajlar ve kampanya güncellemeleri</p>
                        </div>
                        <button className="relative inline-flex h-6 w-11 items-center rounded-full bg-blue-600">
                          <span className="inline-block h-4 w-4 transform rounded-full bg-white transition translate-x-6" />
                        </button>
                      </div>
                      <div className="flex justify-between items-center">
                        <div>
                          <p className="font-medium text-gray-900">SMS Bildirimleri</p>
                          <p className="text-sm text-gray-600">Önemli hesap güncellemeleri</p>
                        </div>
                        <button className="relative inline-flex h-6 w-11 items-center rounded-full bg-gray-200">
                          <span className="inline-block h-4 w-4 transform rounded-full bg-white transition translate-x-1" />
                        </button>
                      </div>
                      <div className="flex justify-between items-center">
                        <div>
                          <p className="font-medium text-gray-900">Pazarlama E-postaları</p>
                          <p className="text-sm text-gray-600">Yeni özellikler ve promosyonlar</p>
                        </div>
                        <button className="relative inline-flex h-6 w-11 items-center rounded-full bg-blue-600">
                          <span className="inline-block h-4 w-4 transform rounded-full bg-white transition translate-x-6" />
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default UserDashboard;