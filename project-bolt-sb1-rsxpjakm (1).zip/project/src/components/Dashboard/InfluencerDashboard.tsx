import React, { useState } from 'react';
import { 
  BarChart3, Users, MessageCircle, DollarSign, Star, Settings, 
  TrendingUp, Calendar, Instagram, Youtube, Play, Eye, 
  CheckCircle, Clock, X, Edit, Camera
} from 'lucide-react';

interface Offer {
  id: number;
  brandName: string;
  brandLogo: string;
  campaignName: string;
  budget: number;
  deadline: string;
  description: string;
  status: 'pending' | 'accepted' | 'rejected';
  requirements: string[];
}

interface Earning {
  id: number;
  campaignName: string;
  brandName: string;
  amount: number;
  date: string;
  status: 'completed' | 'pending' | 'processing';
}

const InfluencerDashboard = () => {
  const [activeTab, setActiveTab] = useState('overview');
  const [profileData, setProfileData] = useState({
    name: 'Ayşe Demir',
    username: 'aysedemir_style',
    bio: 'Moda ve güzellik tutkunu. Sürdürülebilir yaşam savunucusu. İstanbul\'dan sevgilerle ✨',
    location: 'İstanbul',
    categories: ['Moda & Güzellik', 'Sürdürülebilirlik'],
    instagramHandle: 'aysedemir_style',
    instagramData: {
      followers: 15400,
      engagement: 8.2,
      avgLikes: 1250,
      avgComments: 89,
      verified: true
    },
    tiktokHandle: 'aysedemir_style',
    tiktokData: {
      followers: 8900,
      engagement: 12.5,
      avgViews: 2500
    },
    youtubeHandle: 'AyseStyle',
    youtubeData: {
      subscribers: 5200,
      avgViews: 1800,
      totalVideos: 45
    },
    offerStatus: 'Açık' // Yeni alan: teklif durumu
  });

  // Mock data
  const offers: Offer[] = [
    {
      id: 1,
      brandName: 'Organic Beauty Co.',
      brandLogo: 'https://images.pexels.com/photos/1029896/pexels-photo-1029896.jpeg?auto=compress&cs=tinysrgb&w=400',
      campaignName: 'Doğal Cilt Bakım Serisi Tanıtımı',
      budget: 3500,
      deadline: '2024-02-20',
      description: 'Yeni doğal cilt bakım serimizi Instagram story ve post ile tanıtmanızı istiyoruz.',
      status: 'pending',
      requirements: ['1 Instagram Post', '3 Instagram Story', 'Ürün fotoğrafları']
    },
    {
      id: 2,
      brandName: 'Sustainable Fashion',
      brandLogo: 'https://images.pexels.com/photos/1040880/pexels-photo-1040880.jpeg?auto=compress&cs=tinysrgb&w=400',
      campaignName: 'Sürdürülebilir Moda Koleksiyonu',
      budget: 2800,
      deadline: '2024-02-25',
      description: 'Çevre dostu moda koleksiyonumuzu takipçilerinizle paylaşın.',
      status: 'pending',
      requirements: ['2 Instagram Post', '5 Instagram Story', 'Reels video']
    }
  ];

  const earnings: Earning[] = [
    {
      id: 1,
      campaignName: 'Kış Koleksiyonu Lansmanı',
      brandName: 'Fashion Brand',
      amount: 4200,
      date: '2024-01-15',
      status: 'completed'
    },
    {
      id: 2,
      campaignName: 'Organik Kozmetik Tanıtımı',
      brandName: 'Beauty Co.',
      amount: 3100,
      date: '2024-01-08',
      status: 'processing'
    }
  ];

  const formatNumber = (num: number) => {
    if (num >= 1000000) return `${(num / 1000000).toFixed(1)}M`;
    if (num >= 1000) return `${(num / 1000).toFixed(1)}K`;
    return num.toString();
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'pending': return 'bg-yellow-100 text-yellow-800';
      case 'accepted': return 'bg-green-100 text-green-800';
      case 'rejected': return 'bg-red-100 text-red-800';
      case 'completed': return 'bg-green-100 text-green-800';
      case 'processing': return 'bg-blue-100 text-blue-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'pending': return 'Bekliyor';
      case 'accepted': return 'Kabul Edildi';
      case 'rejected': return 'Reddedildi';
      case 'completed': return 'Tamamlandı';
      case 'processing': return 'İşleniyor';
      default: return status;
    }
  };

  const handleOfferAction = (offerId: number, action: 'accept' | 'reject') => {
    const actionText = action === 'accept' ? 'kabul edildi' : 'reddedildi';
    alert(`Teklif ${actionText}!`);
  };

  const handleProfileSave = () => {
    alert('Profil bilgileri başarıyla güncellendi!');
  };

  console.log('✅ [InfluencerDashboard with Profile Management] tamamlandı');

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center">
              <div className="w-8 h-8 bg-gradient-to-br from-blue-800 to-orange-600 rounded-lg flex items-center justify-center">
                <span className="text-white font-bold text-sm">Mİ</span>
              </div>
              <span className="ml-2 text-xl font-bold text-gray-900">MikroEtki</span>
            </div>
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2">
                <img
                  src="https://images.pexels.com/photos/1036623/pexels-photo-1036623.jpeg?auto=compress&cs=tinysrgb&w=400"
                  alt="Profile"
                  className="w-8 h-8 rounded-full object-cover"
                />
                <span className="text-sm font-medium text-gray-700">{profileData.name}</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex flex-col lg:flex-row gap-8">
          {/* Sidebar */}
          <div className="lg:w-64 flex-shrink-0">
            <div className="bg-white rounded-2xl shadow-sm border border-gray-200 p-6">
              <nav className="space-y-2">
                <button
                  onClick={() => setActiveTab('overview')}
                  className={`w-full flex items-center space-x-3 px-4 py-3 rounded-xl text-left transition-colors ${
                    activeTab === 'overview' 
                      ? 'bg-orange-50 text-orange-700 border border-orange-200' 
                      : 'text-gray-700 hover:bg-gray-50'
                  }`}
                >
                  <BarChart3 className="w-5 h-5" />
                  <span>Genel Bakış</span>
                </button>
                <button
                  onClick={() => setActiveTab('profile')}
                  className={`w-full flex items-center space-x-3 px-4 py-3 rounded-xl text-left transition-colors ${
                    activeTab === 'profile' 
                      ? 'bg-orange-50 text-orange-700 border border-orange-200' 
                      : 'text-gray-700 hover:bg-gray-50'
                  }`}
                >
                  <Edit className="w-5 h-5" />
                  <span>Profilim</span>
                </button>
                <button
                  onClick={() => setActiveTab('offers')}
                  className={`w-full flex items-center space-x-3 px-4 py-3 rounded-xl text-left transition-colors ${
                    activeTab === 'offers' 
                      ? 'bg-orange-50 text-orange-700 border border-orange-200' 
                      : 'text-gray-700 hover:bg-gray-50'
                  }`}
                >
                  <MessageCircle className="w-5 h-5" />
                  <span>Gelen Teklifler</span>
                  <span className="bg-red-500 text-white text-xs rounded-full px-2 py-1 ml-auto">
                    {offers.filter(o => o.status === 'pending').length}
                  </span>
                </button>
                <button
                  onClick={() => setActiveTab('performance')}
                  className={`w-full flex items-center space-x-3 px-4 py-3 rounded-xl text-left transition-colors ${
                    activeTab === 'performance' 
                      ? 'bg-orange-50 text-orange-700 border border-orange-200' 
                      : 'text-gray-700 hover:bg-gray-50'
                  }`}
                >
                  <TrendingUp className="w-5 h-5" />
                  <span>Performans Raporları</span>
                </button>
                <button
                  onClick={() => setActiveTab('earnings')}
                  className={`w-full flex items-center space-x-3 px-4 py-3 rounded-xl text-left transition-colors ${
                    activeTab === 'earnings' 
                      ? 'bg-orange-50 text-orange-700 border border-orange-200' 
                      : 'text-gray-700 hover:bg-gray-50'
                  }`}
                >
                  <DollarSign className="w-5 h-5" />
                  <span>Kazanç Takibi</span>
                </button>
                <button
                  onClick={() => setActiveTab('settings')}
                  className={`w-full flex items-center space-x-3 px-4 py-3 rounded-xl text-left transition-colors ${
                    activeTab === 'settings' 
                      ? 'bg-orange-50 text-orange-700 border border-orange-200' 
                      : 'text-gray-700 hover:bg-gray-50'
                  }`}
                >
                  <Settings className="w-5 h-5" />
                  <span>Ayarlar</span>
                </button>
              </nav>
            </div>
          </div>

          {/* Main Content */}
          <div className="flex-1">
            {activeTab === 'overview' && (
              <div className="space-y-8">
                <div>
                  <h1 className="text-3xl font-bold text-gray-900 mb-2">Hoş Geldin, {profileData.name}!</h1>
                  <p className="text-gray-600">Hesabınızın genel durumu ve performans metrikleri</p>
                </div>

                {/* Stats Cards */}
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                  <div className="bg-white rounded-2xl p-6 shadow-sm border border-gray-200">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm text-gray-600">Toplam Takipçi</p>
                        <p className="text-2xl font-bold text-gray-900">
                          {formatNumber(profileData.instagramData.followers + profileData.tiktokData.followers + profileData.youtubeData.subscribers)}
                        </p>
                      </div>
                      <div className="w-12 h-12 bg-blue-100 rounded-xl flex items-center justify-center">
                        <Users className="w-6 h-6 text-blue-600" />
                      </div>
                    </div>
                  </div>
                  <div className="bg-white rounded-2xl p-6 shadow-sm border border-gray-200">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm text-gray-600">Ortalama Etkileşim</p>
                        <p className="text-2xl font-bold text-gray-900">8.9%</p>
                      </div>
                      <div className="w-12 h-12 bg-green-100 rounded-xl flex items-center justify-center">
                        <TrendingUp className="w-6 h-6 text-green-600" />
                      </div>
                    </div>
                  </div>
                  <div className="bg-white rounded-2xl p-6 shadow-sm border border-gray-200">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm text-gray-600">Bu Ay Kazanç</p>
                        <p className="text-2xl font-bold text-gray-900">₺7.3K</p>
                      </div>
                      <div className="w-12 h-12 bg-orange-100 rounded-xl flex items-center justify-center">
                        <DollarSign className="w-6 h-6 text-orange-600" />
                      </div>
                    </div>
                  </div>
                  <div className="bg-white rounded-2xl p-6 shadow-sm border border-gray-200">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm text-gray-600">Aktif Kampanyalar</p>
                        <p className="text-2xl font-bold text-gray-900">2</p>
                      </div>
                      <div className="w-12 h-12 bg-purple-100 rounded-xl flex items-center justify-center">
                        <Calendar className="w-6 h-6 text-purple-600" />
                      </div>
                    </div>
                  </div>
                </div>

                {/* Social Media Overview */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div className="bg-white rounded-2xl p-6 shadow-sm border border-gray-200">
                    <div className="flex items-center space-x-3 mb-4">
                      <Instagram className="w-6 h-6 text-pink-600" />
                      <h3 className="font-semibold text-gray-900">Instagram</h3>
                      {profileData.instagramData.verified && (
                        <div className="w-5 h-5 bg-blue-500 rounded-full flex items-center justify-center">
                          <div className="w-2 h-2 bg-white rounded-full"></div>
                        </div>
                      )}
                    </div>
                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <span className="text-gray-600">Takipçi:</span>
                        <span className="font-semibold">{formatNumber(profileData.instagramData.followers)}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-600">Etkileşim:</span>
                        <span className="font-semibold">{profileData.instagramData.engagement}%</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-600">Ort. Beğeni:</span>
                        <span className="font-semibold">{formatNumber(profileData.instagramData.avgLikes)}</span>
                      </div>
                    </div>
                  </div>

                  <div className="bg-white rounded-2xl p-6 shadow-sm border border-gray-200">
                    <div className="flex items-center space-x-3 mb-4">
                      <Play className="w-6 h-6 text-black" />
                      <h3 className="font-semibold text-gray-900">TikTok</h3>
                    </div>
                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <span className="text-gray-600">Takipçi:</span>
                        <span className="font-semibold">{formatNumber(profileData.tiktokData.followers)}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-600">Etkileşim:</span>
                        <span className="font-semibold">{profileData.tiktokData.engagement}%</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-600">Ort. İzlenme:</span>
                        <span className="font-semibold">{formatNumber(profileData.tiktokData.avgViews)}</span>
                      </div>
                    </div>
                  </div>

                  <div className="bg-white rounded-2xl p-6 shadow-sm border border-gray-200">
                    <div className="flex items-center space-x-3 mb-4">
                      <Youtube className="w-6 h-6 text-red-600" />
                      <h3 className="font-semibold text-gray-900">YouTube</h3>
                    </div>
                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <span className="text-gray-600">Abone:</span>
                        <span className="font-semibold">{formatNumber(profileData.youtubeData.subscribers)}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-600">Video Sayısı:</span>
                        <span className="font-semibold">{profileData.youtubeData.totalVideos}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-600">Ort. İzlenme:</span>
                        <span className="font-semibold">{formatNumber(profileData.youtubeData.avgViews)}</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {activeTab === 'profile' && (
              <div className="space-y-8">
                <div>
                  <h1 className="text-3xl font-bold text-gray-900 mb-2">Profilim</h1>
                  <p className="text-gray-600">Profilinizi güncelleyin ve sosyal medya hesaplarınızı yönetin</p>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                  {/* Basic Info */}
                  <div className="bg-white rounded-2xl shadow-sm border border-gray-200 p-6">
                    <h2 className="text-lg font-semibold text-gray-900 mb-6">Temel Bilgiler</h2>
                    <div className="space-y-4">
                      <div className="flex items-center space-x-4 mb-6">
                        <div className="relative">
                          <img
                            src="https://images.pexels.com/photos/1036623/pexels-photo-1036623.jpeg?auto=compress&cs=tinysrgb&w=400"
                            alt="Profile"
                            className="w-20 h-20 rounded-full object-cover"
                          />
                          <button className="absolute bottom-0 right-0 w-6 h-6 bg-blue-600 rounded-full flex items-center justify-center text-white hover:bg-blue-700 transition-colors">
                            <Camera className="w-3 h-3" />
                          </button>
                        </div>
                        <div>
                          <h3 className="font-semibold text-gray-900">{profileData.name}</h3>
                          <p className="text-gray-600">@{profileData.username}</p>
                        </div>
                      </div>
                      
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">
                          Ad Soyad
                        </label>
                        <input
                          type="text"
                          value={profileData.name}
                          onChange={(e) => setProfileData({...profileData, name: e.target.value})}
                          className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                        />
                      </div>
                      
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">
                          Biyografi
                        </label>
                        <textarea
                          value={profileData.bio}
                          onChange={(e) => setProfileData({...profileData, bio: e.target.value})}
                          rows={3}
                          className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                        />
                      </div>
                      
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">
                          Konum
                        </label>
                        <input
                          type="text"
                          value={profileData.location}
                          onChange={(e) => setProfileData({...profileData, location: e.target.value})}
                          className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                        />
                      </div>

                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">
                          Teklif Durumu
                        </label>
                        <select
                          value={profileData.offerStatus}
                          onChange={(e) => setProfileData({...profileData, offerStatus: e.target.value})}
                          className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                        >
                          <option value="Açık">Açık - Yeni teklifler kabul ediyorum</option>
                          <option value="Sınırlı">Sınırlı - Sadece seçili markalardan</option>
                          <option value="Kapalı">Kapalı - Şu anda teklif almıyorum</option>
                        </select>
                      </div>
                      
                      <button 
                        onClick={handleProfileSave}
                        className="w-full bg-orange-600 text-white py-3 rounded-xl hover:bg-orange-700 transition-colors"
                      >
                        Değişiklikleri Kaydet
                      </button>
                    </div>
                  </div>

                  {/* Social Media Accounts */}
                  <div className="bg-white rounded-2xl shadow-sm border border-gray-200 p-6">
                    <h2 className="text-lg font-semibold text-gray-900 mb-6">Sosyal Medya Hesapları</h2>
                    <div className="space-y-6">
                      {/* Instagram */}
                      <div className="border border-gray-200 rounded-xl p-4">
                        <div className="flex items-center space-x-3 mb-4">
                          <Instagram className="w-6 h-6 text-pink-600" />
                          <h4 className="font-semibold text-gray-900">Instagram</h4>
                        </div>
                        <input
                          type="text"
                          value={profileData.instagramHandle}
                          onChange={(e) => setProfileData({...profileData, instagramHandle: e.target.value})}
                          className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-pink-500 focus:border-transparent mb-3"
                          placeholder="instagram_kullanici_adi"
                        />
                        <div className="bg-pink-50 p-3 rounded-lg">
                          <div className="grid grid-cols-2 gap-4 text-sm">
                            <div>
                              <span className="text-gray-600">Takipçi:</span>
                              <span className="font-semibold ml-1">{formatNumber(profileData.instagramData.followers)}</span>
                            </div>
                            <div>
                              <span className="text-gray-600">Etkileşim:</span>
                              <span className="font-semibold ml-1">{profileData.instagramData.engagement}%</span>
                            </div>
                          </div>
                        </div>
                      </div>

                      {/* TikTok */}
                      <div className="border border-gray-200 rounded-xl p-4">
                        <div className="flex items-center space-x-3 mb-4">
                          <Play className="w-6 h-6 text-black" />
                          <h4 className="font-semibold text-gray-900">TikTok</h4>
                        </div>
                        <input
                          type="text"
                          value={profileData.tiktokHandle}
                          onChange={(e) => setProfileData({...profileData, tiktokHandle: e.target.value})}
                          className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-gray-500 focus:border-transparent mb-3"
                          placeholder="tiktok_kullanici_adi"
                        />
                        <div className="bg-gray-50 p-3 rounded-lg">
                          <div className="grid grid-cols-2 gap-4 text-sm">
                            <div>
                              <span className="text-gray-600">Takipçi:</span>
                              <span className="font-semibold ml-1">{formatNumber(profileData.tiktokData.followers)}</span>
                            </div>
                            <div>
                              <span className="text-gray-600">Etkileşim:</span>
                              <span className="font-semibold ml-1">{profileData.tiktokData.engagement}%</span>
                            </div>
                          </div>
                        </div>
                      </div>

                      {/* YouTube */}
                      <div className="border border-gray-200 rounded-xl p-4">
                        <div className="flex items-center space-x-3 mb-4">
                          <Youtube className="w-6 h-6 text-red-600" />
                          <h4 className="font-semibold text-gray-900">YouTube</h4>
                        </div>
                        <input
                          type="text"
                          value={profileData.youtubeHandle}
                          onChange={(e) => setProfileData({...profileData, youtubeHandle: e.target.value})}
                          className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent mb-3"
                          placeholder="youtube_kanal_adi"
                        />
                        <div className="bg-red-50 p-3 rounded-lg">
                          <div className="grid grid-cols-2 gap-4 text-sm">
                            <div>
                              <span className="text-gray-600">Abone:</span>
                              <span className="font-semibold ml-1">{formatNumber(profileData.youtubeData.subscribers)}</span>
                            </div>
                            <div>
                              <span className="text-gray-600">Video:</span>
                              <span className="font-semibold ml-1">{profileData.youtubeData.totalVideos}</span>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {activeTab === 'offers' && (
              <div className="space-y-8">
                <div>
                  <h1 className="text-3xl font-bold text-gray-900 mb-2">Gelen Teklifler</h1>
                  <p className="text-gray-600">Markalardan gelen iş birliği tekliflerini yönetin</p>
                </div>

                <div className="space-y-6">
                  {offers.map((offer) => (
                    <div key={offer.id} className="bg-white rounded-2xl shadow-sm border border-gray-200 p-6">
                      <div className="flex items-start justify-between mb-4">
                        <div className="flex items-center space-x-4">
                          <img
                            src={offer.brandLogo}
                            alt={offer.brandName}
                            className="w-16 h-16 rounded-xl object-cover"
                          />
                          <div>
                            <h3 className="text-xl font-semibold text-gray-900">{offer.campaignName}</h3>
                            <p className="text-gray-600">{offer.brandName}</p>
                            <span className={`inline-block px-3 py-1 rounded-full text-sm font-medium mt-2 ${getStatusColor(offer.status)}`}>
                              {getStatusText(offer.status)}
                            </span>
                          </div>
                        </div>
                        <div className="text-right">
                          <p className="text-2xl font-bold text-gray-900">₺{offer.budget.toLocaleString('tr-TR')}</p>
                          <p className="text-sm text-gray-600">Son tarih: {offer.deadline}</p>
                        </div>
                      </div>

                      <p className="text-gray-700 mb-4">{offer.description}</p>

                      <div className="mb-6">
                        <h4 className="font-medium text-gray-900 mb-2">Gereksinimler:</h4>
                        <div className="flex flex-wrap gap-2">
                          {offer.requirements.map((req, index) => (
                            <span key={index} className="px-3 py-1 bg-gray-100 text-gray-700 rounded-full text-sm">
                              {req}
                            </span>
                          ))}
                        </div>
                      </div>

                      {offer.status === 'pending' && (
                        <div className="flex space-x-4">
                          <button 
                            onClick={() => handleOfferAction(offer.id, 'accept')}
                            className="flex-1 bg-green-600 text-white py-3 rounded-xl hover:bg-green-700 transition-colors flex items-center justify-center space-x-2"
                          >
                            <CheckCircle className="w-5 h-5" />
                            <span>Kabul Et</span>
                          </button>
                          <button 
                            onClick={() => handleOfferAction(offer.id, 'reject')}
                            className="flex-1 bg-red-600 text-white py-3 rounded-xl hover:bg-red-700 transition-colors flex items-center justify-center space-x-2"
                          >
                            <X className="w-5 h-5" />
                            <span>Reddet</span>
                          </button>
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            )}

            {activeTab === 'earnings' && (
              <div className="space-y-8">
                <div>
                  <h1 className="text-3xl font-bold text-gray-900 mb-2">Kazanç Takibi</h1>
                  <p className="text-gray-600">Gelirlerinizi takip edin ve ödemelerinizi yönetin</p>
                </div>

                {/* Earnings Summary */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div className="bg-white rounded-2xl p-6 shadow-sm border border-gray-200">
                    <h3 className="text-lg font-semibold text-gray-900 mb-2">Bu Ay</h3>
                    <p className="text-3xl font-bold text-green-600">₺7,300</p>
                    <p className="text-sm text-gray-600 mt-1">2 kampanya</p>
                  </div>
                  <div className="bg-white rounded-2xl p-6 shadow-sm border border-gray-200">
                    <h3 className="text-lg font-semibold text-gray-900 mb-2">Toplam Kazanç</h3>
                    <p className="text-3xl font-bold text-gray-900">₺45,200</p>
                    <p className="text-sm text-gray-600 mt-1">12 kampanya</p>
                  </div>
                  <div className="bg-white rounded-2xl p-6 shadow-sm border border-gray-200">
                    <h3 className="text-lg font-semibold text-gray-900 mb-2">Bekleyen Ödeme</h3>
                    <p className="text-3xl font-bold text-orange-600">₺3,100</p>
                    <p className="text-sm text-gray-600 mt-1">1 kampanya</p>
                  </div>
                </div>

                {/* Earnings History */}
                <div className="bg-white rounded-2xl shadow-sm border border-gray-200">
                  <div className="p-6 border-b border-gray-200">
                    <h2 className="text-lg font-semibold text-gray-900">Kazanç Geçmişi</h2>
                  </div>
                  <div className="divide-y divide-gray-200">
                    {earnings.map((earning) => (
                      <div key={earning.id} className="p-6 flex justify-between items-center">
                        <div>
                          <h3 className="font-medium text-gray-900">{earning.campaignName}</h3>
                          <p className="text-sm text-gray-600">{earning.brandName}</p>
                          <p className="text-sm text-gray-500">{earning.date}</p>
                        </div>
                        <div className="text-right">
                          <p className="text-xl font-bold text-gray-900">₺{earning.amount.toLocaleString('tr-TR')}</p>
                          <span className={`px-2 py-1 rounded-full text-xs font-medium ${getStatusColor(earning.status)}`}>
                            {getStatusText(earning.status)}
                          </span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {activeTab === 'performance' && (
              <div className="space-y-8">
                <div>
                  <h1 className="text-3xl font-bold text-gray-900 mb-2">Performans Raporları</h1>
                  <p className="text-gray-600">Hesaplarınızın detaylı analiz ve performans verileri</p>
                </div>

                {/* Performance Charts Placeholder */}
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                  <div className="bg-white rounded-2xl shadow-sm border border-gray-200 p-6">
                    <h2 className="text-lg font-semibold text-gray-900 mb-6">Takipçi Büyümesi</h2>
                    <div className="h-64 bg-gray-50 rounded-xl flex items-center justify-center">
                      <p className="text-gray-500">Grafik burada görünecek</p>
                    </div>
                  </div>
                  
                  <div className="bg-white rounded-2xl shadow-sm border border-gray-200 p-6">
                    <h2 className="text-lg font-semibold text-gray-900 mb-6">Etkileşim Oranı Trendi</h2>
                    <div className="h-64 bg-gray-50 rounded-xl flex items-center justify-center">
                      <p className="text-gray-500">Grafik burada görünecek</p>
                    </div>
                  </div>
                </div>

                {/* Demographics */}
                <div className="bg-white rounded-2xl shadow-sm border border-gray-200 p-6">
                  <h2 className="text-lg font-semibold text-gray-900 mb-6">Takipçi Demografisi</h2>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    <div>
                      <h3 className="font-medium text-gray-900 mb-4">Yaş Dağılımı</h3>
                      <div className="space-y-2">
                        <div className="flex justify-between items-center">
                          <span className="text-sm text-gray-600">18-24</span>
                          <span className="text-sm font-medium">35%</span>
                        </div>
                        <div className="flex justify-between items-center">
                          <span className="text-sm text-gray-600">25-34</span>
                          <span className="text-sm font-medium">42%</span>
                        </div>
                        <div className="flex justify-between items-center">
                          <span className="text-sm text-gray-600">35-44</span>
                          <span className="text-sm font-medium">18%</span>
                        </div>
                        <div className="flex justify-between items-center">
                          <span className="text-sm text-gray-600">45+</span>
                          <span className="text-sm font-medium">5%</span>
                        </div>
                      </div>
                    </div>
                    
                    <div>
                      <h3 className="font-medium text-gray-900 mb-4">Cinsiyet Dağılımı</h3>
                      <div className="space-y-2">
                        <div className="flex justify-between items-center">
                          <span className="text-sm text-gray-600">Kadın</span>
                          <span className="text-sm font-medium">68%</span>
                        </div>
                        <div className="flex justify-between items-center">
                          <span className="text-sm text-gray-600">Erkek</span>
                          <span className="text-sm font-medium">32%</span>
                        </div>
                      </div>
                    </div>
                    
                    <div>
                      <h3 className="font-medium text-gray-900 mb-4">Konum Dağılımı</h3>
                      <div className="space-y-2">
                        <div className="flex justify-between items-center">
                          <span className="text-sm text-gray-600">İstanbul</span>
                          <span className="text-sm font-medium">45%</span>
                        </div>
                        <div className="flex justify-between items-center">
                          <span className="text-sm text-gray-600">Ankara</span>
                          <span className="text-sm font-medium">15%</span>
                        </div>
                        <div className="flex justify-between items-center">
                          <span className="text-sm text-gray-600">İzmir</span>
                          <span className="text-sm font-medium">12%</span>
                        </div>
                        <div className="flex justify-between items-center">
                          <span className="text-sm text-gray-600">Diğer</span>
                          <span className="text-sm font-medium">28%</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {activeTab === 'settings' && (
              <div className="space-y-8">
                <div>
                  <h1 className="text-3xl font-bold text-gray-900 mb-2">Hesap Ayarları</h1>
                  <p className="text-gray-600">Hesap tercihlerinizi ve bildirim ayarlarınızı yönetin</p>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                  {/* Account Settings */}
                  <div className="bg-white rounded-2xl shadow-sm border border-gray-200 p-6">
                    <h2 className="text-lg font-semibold text-gray-900 mb-6">Hesap Bilgileri</h2>
                    <div className="space-y-4">
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">
                          E-posta
                        </label>
                        <input
                          type="email"
                          defaultValue="ayse@example.com"
                          className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">
                          Telefon
                        </label>
                        <input
                          type="tel"
                          defaultValue="+90 532 123 45 67"
                          className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                        />
                      </div>
                      <button className="w-full bg-orange-600 text-white py-3 rounded-xl hover:bg-orange-700 transition-colors">
                        Değişiklikleri Kaydet
                      </button>
                    </div>
                  </div>

                  {/* Notification Settings */}
                  <div className="bg-white rounded-2xl shadow-sm border border-gray-200 p-6">
                    <h2 className="text-lg font-semibold text-gray-900 mb-6">Bildirim Tercihleri</h2>
                    <div className="space-y-4">
                      <div className="flex justify-between items-center">
                        <div>
                          <p className="font-medium text-gray-900">Yeni Teklifler</p>
                          <p className="text-sm text-gray-600">Markalardan gelen yeni iş teklifleri</p>
                        </div>
                        <button className="relative inline-flex h-6 w-11 items-center rounded-full bg-orange-600">
                          <span className="inline-block h-4 w-4 transform rounded-full bg-white transition translate-x-6" />
                        </button>
                      </div>
                      <div className="flex justify-between items-center">
                        <div>
                          <p className="font-medium text-gray-900">Kampanya Güncellemeleri</p>
                          <p className="text-sm text-gray-600">Aktif kampanyalarınızla ilgili bildirimler</p>
                        </div>
                        <button className="relative inline-flex h-6 w-11 items-center rounded-full bg-orange-600">
                          <span className="inline-block h-4 w-4 transform rounded-full bg-white transition translate-x-6" />
                        </button>
                      </div>
                      <div className="flex justify-between items-center">
                        <div>
                          <p className="font-medium text-gray-900">Ödeme Bildirimleri</p>
                          <p className="text-sm text-gray-600">Kazanç ve ödeme durumu güncellemeleri</p>
                        </div>
                        <button className="relative inline-flex h-6 w-11 items-center rounded-full bg-gray-200">
                          <span className="inline-block h-4 w-4 transform rounded-full bg-white transition translate-x-1" />
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default InfluencerDashboard;