import React, { useState } from 'react';
import { X, Mail, Send, User, Building } from 'lucide-react';

interface ContactModalProps {
  isOpen: boolean;
  onClose: () => void;
  influencer: {
    id: number;
    name: string;
    username: string;
    avatar: string;
    category: string;
    priceRange: string;
  };
}

const ContactModal: React.FC<ContactModalProps> = ({ isOpen, onClose, influencer }) => {
  const [formData, setFormData] = useState({
    subject: '',
    message: '',
    budget: '',
    timeline: '',
    campaignType: 'post'
  });
  const [isSubmitting, setIsSubmitting] = useState(false);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1500));

    // Show success message
    alert(`Mesajınız ${influencer.name}'e başarıyla gönderildi! En kısa sürede size dönüş yapacaktır.`);
    
    // Reset form and close modal
    setFormData({
      subject: '',
      message: '',
      budget: '',
      timeline: '',
      campaignType: 'post'
    });
    setIsSubmitting(false);
    onClose();
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-gray-200">
          <div className="flex items-center space-x-4">
            <img
              src={influencer.avatar}
              alt={influencer.name}
              className="w-12 h-12 rounded-full object-cover"
            />
            <div>
              <h2 className="text-xl font-bold text-gray-900">{influencer.name} ile İletişime Geç</h2>
              <p className="text-gray-600">@{influencer.username} • {influencer.category}</p>
            </div>
          </div>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-600">
            <X className="w-6 h-6" />
          </button>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="p-6 space-y-6">
          {/* Campaign Type */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Kampanya Türü
            </label>
            <select
              name="campaignType"
              value={formData.campaignType}
              onChange={handleInputChange}
              className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              required
            >
              <option value="post">Instagram Post</option>
              <option value="story">Instagram Story</option>
              <option value="reel">Instagram Reel</option>
              <option value="tiktok">TikTok Video</option>
              <option value="youtube">YouTube Video</option>
              <option value="multiple">Çoklu Platform</option>
            </select>
          </div>

          {/* Subject */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Konu
            </label>
            <input
              type="text"
              name="subject"
              value={formData.subject}
              onChange={handleInputChange}
              placeholder="Örn: Yeni ürün lansmanı için iş birliği"
              className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              required
            />
          </div>

          {/* Budget */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Bütçe Aralığı
            </label>
            <select
              name="budget"
              value={formData.budget}
              onChange={handleInputChange}
              className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              required
            >
              <option value="">Bütçe seçin</option>
              <option value="1000-2500">₺1,000 - ₺2,500</option>
              <option value="2500-5000">₺2,500 - ₺5,000</option>
              <option value="5000-10000">₺5,000 - ₺10,000</option>
              <option value="10000+">₺10,000+</option>
              <option value="negotiable">Pazarlık edilebilir</option>
            </select>
          </div>

          {/* Timeline */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Zaman Çizelgesi
            </label>
            <select
              name="timeline"
              value={formData.timeline}
              onChange={handleInputChange}
              className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              required
            >
              <option value="">Zaman seçin</option>
              <option value="asap">En kısa sürede</option>
              <option value="1week">1 hafta içinde</option>
              <option value="2weeks">2 hafta içinde</option>
              <option value="1month">1 ay içinde</option>
              <option value="flexible">Esnek</option>
            </select>
          </div>

          {/* Message */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Mesajınız
            </label>
            <textarea
              name="message"
              value={formData.message}
              onChange={handleInputChange}
              rows={5}
              placeholder="Kampanyanız hakkında detayları paylaşın..."
              className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent resize-none"
              required
            />
          </div>

          {/* Price Info */}
          <div className="bg-blue-50 border border-blue-200 rounded-xl p-4">
            <div className="flex items-center space-x-2 mb-2">
              <Building className="w-5 h-5 text-blue-600" />
              <span className="font-medium text-blue-900">Fiyat Bilgisi</span>
            </div>
            <p className="text-blue-800 text-sm">
              {influencer.name}'in ortalama fiyat aralığı: <strong>{influencer.priceRange}</strong>
            </p>
            <p className="text-blue-700 text-xs mt-1">
              Final fiyat kampanya detaylarına göre belirlenecektir.
            </p>
          </div>

          {/* Submit Button */}
          <div className="flex space-x-4">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 border border-gray-300 text-gray-700 py-3 rounded-xl hover:bg-gray-50 transition-colors font-medium"
            >
              İptal
            </button>
            <button
              type="submit"
              disabled={isSubmitting}
              className="flex-1 bg-blue-600 text-white py-3 rounded-xl hover:bg-blue-700 transition-colors font-medium flex items-center justify-center space-x-2 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {isSubmitting ? (
                <>
                  <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                  <span>Gönderiliyor...</span>
                </>
              ) : (
                <>
                  <Send className="w-4 h-4" />
                  <span>Mesaj Gönder</span>
                </>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default ContactModal;